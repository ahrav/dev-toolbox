---
name: rust-perf-triage
description: Analyze Rust performance issues from Criterion benchmarks, flamegraphs, and perf data. Use when diagnosing performance bottlenecks, allocation hot spots, lock contention, cache misses, async inefficiencies, or comparing benchmark results. Produces prioritized findings with concrete optimization recommendations and experiment plans.
---

# Rust Performance Triage Coach

Systematic workflow for analyzing Rust performance data and producing actionable optimization plans.

## Triage Workflow

Follow this sequence to identify and prioritize performance bottlenecks:

### 1. Gather Performance Data

**Identify what data is available:**
- Criterion benchmark output (JSON or terminal output)
- Flamegraphs (SVG or perf.data)
- perf stat counters
- Tokio console traces
- Code excerpts with suspected hot paths

**Use available scripts:**
- `scripts/parse_criterion.py` - Extract and compare Criterion results
- `scripts/perf_counters.sh` - Run perf with appropriate counter sets

### 2. Initial Analysis

**For Criterion benchmarks:**
- Identify regressions (>5% slower) and improvements (>5% faster)
- Note high variance (std dev >10%) - indicates measurement instability
- Check for bimodal distributions - suggests cache or scheduling effects
- Load `references/profiling-tools.md` for interpretation guidance

**For flamegraphs:**
- Scan for widest boxes - these consume most time
- Look for allocation patterns (alloc, dealloc, clone, memcpy)
- Identify lock contention (mutex, parking_lot, RwLock)
- Check for async overhead (spawn, poll, waker)
- Load `references/profiling-tools.md` for reading strategies

**For perf counters:**
- Calculate IPC (instructions per cycle): >1.5 good, <1.0 memory-bound
- Compute cache miss rate: <3% good, >10% problematic
- Check branch miss rate: <2% good, >5% problematic
- Load `references/profiling-tools.md` for counter interpretation

### 3. Diagnose Root Causes

Match observed patterns to known bottleneck types by loading `references/rust-perf-patterns.md`:

**Allocation hot spots:**
- Vec/String growth without reserve
- Clone storms in loops
- Box<dyn Trait> in hot paths
- String concatenation patterns

**Lock contention:**
- Wide critical sections
- Mutex instead of RwLock
- False sharing (same cache line)
- Async locks held across await

**Cache inefficiency:**
- Large structs causing cache bloat
- Random access patterns
- AoS vs SoA layout issues
- Alignment problems

**Async bottlenecks:**
- Excessive task spawning
- Blocking operations in async context
- Channel saturation
- Single-threaded bottlenecks

### 4. Formulate Recommendations

For each identified bottleneck, load `references/optimization-techniques.md` and provide:

**Concrete code changes:**
- Show before/after code snippets
- Use specific Rust patterns (Vec::with_capacity, mem::take, etc.)
- Reference appropriate crates (bytes, smallvec, ahash, etc.)

**Build flag optimizations:**
- Profile-specific settings (lto, codegen-units)
- Target CPU features (AVX2, FMA, BMI2)
- When to use each flag

**Expected impact:**
- Quantify expected improvement (5-15%, 2-3x, etc.)
- Note measurement approach (Criterion, perf stat, etc.)
- Flag risks or trade-offs (compile time, portability)

### 5. Produce Experiment Plan

Generate a prioritized, ordered checklist:

**Format:**
```markdown
## Experiment Plan

### High Priority (Expected >20% improvement)
1. [ ] Pre-allocate Vec with capacity in hot loop (line 42)
   - Expected: 25-30% improvement
   - Validate: Criterion benchmark `process_batch`
   - Risk: Low

2. [ ] Replace String + concat with String::with_capacity (line 67)
   - Expected: 15-20% improvement  
   - Validate: Flamegraph width of `alloc`
   - Risk: Low

### Medium Priority (Expected 5-20% improvement)
3. [ ] Switch to FxHashMap for integer keys (line 103)
   - Expected: 10-15% improvement
   - Validate: Criterion benchmark `lookup_intensive`
   - Risk: Low (non-cryptographic is acceptable)

### Low Priority (Expected <5% improvement)
4. [ ] Add #[inline] to small hot functions
   - Expected: 2-5% improvement
   - Validate: Check flamegraph function call overhead
   - Risk: Very low

### Measurement Probes
- Add Criterion benchmark for `process_batch` with varying sizes
- Collect perf stat before/after for cache miss rate
- Profile with flamegraph after each change to validate
```

**Prioritization criteria:**
- Impact: Expected improvement magnitude
- Effort: Implementation complexity
- Risk: Potential for introducing bugs or regressions
- Measurability: Ease of validation

## Output Format

Structure findings as:

### Performance Analysis
[Brief summary of the performance issue and overall diagnosis]

### Bottleneck Findings
[Ordered list of identified issues with severity]

### Detailed Recommendations
[For each bottleneck: diagnosis, code changes, expected impact]

### Experiment Plan
[Prioritized checklist with validation approach]

## Using Bundled Resources

### References
- `references/rust-perf-patterns.md` - Pattern matching for bottleneck identification
- `references/profiling-tools.md` - Interpreting Criterion, flamegraphs, perf, tokio-console
- `references/optimization-techniques.md` - Concrete solutions and code patterns

Load references based on:
- Available data type (flamegraph → profiling-tools.md)
- Identified pattern (allocation hot spot → rust-perf-patterns.md)
- Solution phase (recommendations → optimization-techniques.md)

### Scripts
- `scripts/parse_criterion.py <file.json>` - Parse single Criterion run
- `scripts/parse_criterion.py --compare old.json new.json` - Compare two runs
- `scripts/perf_counters.sh <preset> <command>` - Run perf with counter sets
  - Presets: basic, memory, branch, tlb, all

Use scripts to extract structured data from raw performance outputs.

## Common Query Patterns

**Flamegraph analysis:**
"Explain this flamegraph and call out top optimization opportunities"
→ Load profiling-tools.md, identify wide boxes, match to patterns, suggest fixes

**Benchmark comparison:**
"Compare these two Criterion runs and summarize regressions"
→ Use parse_criterion.py, load profiling-tools.md, prioritize >5% changes

**Async performance:**
"Diagnose latency spikes under Tokio load"
→ Load rust-perf-patterns.md async section, check for blocking, contention

**Allocation optimization:**
"Reduce allocations in this Bytes/Vec pipeline"
→ Load optimization-techniques.md zero-copy section, suggest Bytes patterns

**Low-level optimization:**
"Suggest SIMD or faster hashing for this hot path"
→ Load optimization-techniques.md, check for vectorization opportunities

**Build optimization:**
"Recommend build flags for maximum throughput on x86-64"
→ Load optimization-techniques.md build flags section, target-cpu tuning
