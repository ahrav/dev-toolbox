# Interpreting Performance Profiling Data

## Criterion Benchmark Reports

### Key Metrics
- **Time (mean)**: Central measure. Focus here first.
- **Std dev**: High deviation (>10%) indicates unstable benchmark or system noise.
- **Throughput**: ops/sec or bytes/sec. Better than time for I/O workloads.
- **Outliers**: Mild/severe outliers indicate GC pauses, interrupts, or thermal throttling.

### Comparing Runs
- **Change percentage**: >5% is meaningful, <2% is noise unless sample count is very high.
- **Confidence intervals**: Non-overlapping intervals = statistically significant change.
- **Regression vs improvement**: Red = slower, green = faster in Criterion HTML.

### Reading Criterion Output
```
benchmark_name  time:   [144.23 µs 145.67 µs 147.12 µs]
                change: [-2.5% -0.3% +1.8%] (p = 0.42 > 0.05)
```
- First line: [lower_bound mean upper_bound] from current run
- Second line: [lower_change mean_change upper_change] vs baseline
- p-value: <0.05 = significant change

### Red Flags
- **Bimodal distribution**: Two distinct peaks suggests cache effects or task scheduling
- **High outliers**: >10% outliers = unstable measurement
- **Wide confidence interval**: Increase sample size or reduce system load

## Flamegraph Analysis

### Reading Strategy
- **Width = time**: Wider boxes = more time spent
- **Height = call depth**: Deep stacks = many function calls
- **Color**: Usually by package or random (not meaningful unless configured)

### Identifying Hot Spots
1. **Scan top of graph**: Widest top-level boxes are entry points
2. **Look for plateaus**: Wide, flat sections are hot code
3. **Identify towers**: Tall, narrow stacks = deep call chains, possibly inefficient
4. **Search for specific functions**: Use search box for memcpy, alloc, lock

### Common Patterns
- **Wide alloc/dealloc**: Allocation churn
- **Wide memcpy/memmove**: Excessive copying
- **Wide lock functions**: Lock contention
- **Jagged top**: Good—many small functions, work distributed
- **Smooth plateau**: Potential hot spot—single function dominates

### Optimization Priority
1. **Widest boxes at highest stack level**: Most impact
2. **Repeated patterns**: Indicates algorithmic issue
3. **Library functions dominating**: May need different approach (e.g., zero-copy)

### Flamegraph Colors
- If colored by package: Different colors = different crates. Find your crate's color.
- Random coloring: Ignore color, focus on width only.

## perf stat Counters

### Core Metrics
```
perf stat -e cycles,instructions,cache-misses,cache-references,branches,branch-misses <command>
```

- **IPC (instructions per cycle)**: >1.5 = good, <1.0 = memory/cache bound
- **Cache miss rate**: cache-misses/cache-references. <3% = good, >10% = problem
- **Branch miss rate**: branch-misses/branches. <2% = good, >5% = problem

### Interpreting Results
- **Low IPC + high cache miss**: Memory bottleneck, improve data locality
- **Low IPC + high branch miss**: Control flow issues, simplify conditionals
- **High IPC**: CPU-bound, may benefit from SIMD or algorithmic changes

### Common Counter Sets

**Memory analysis:**
```
perf stat -e L1-dcache-load-misses,L1-dcache-loads,LLC-load-misses,LLC-loads
```

**Branch analysis:**
```
perf stat -e branch-instructions,branch-misses,branch-load-misses
```

**TLB analysis:**
```
perf stat -e dTLB-load-misses,dTLB-loads,iTLB-load-misses,iTLB-loads
```

### Red Flags
- **IPC < 0.5**: Severe memory stall or contention
- **LLC miss rate > 20%**: Data doesn't fit in L3, consider working set size
- **dTLB miss rate > 5%**: TLB pressure, too many pages

## Tokio Console

### Task View
- **Total**: Number of tasks spawned
- **Busy**: Tasks actively running (should be ~= CPU core count)
- **Idle**: Tasks waiting for async operations
- **Target**: Annotation from #[instrument], helps identify task type

### Task Details
- **Polls**: Number of times task polled. High = frequent wakeups, potential spinning
- **Total time**: Cumulative time task existed
- **Busy time**: Time actually executing (not awaiting)
- **Scheduled time**: Time waiting in executor queue before running
- **Idle time**: Time spent awaiting futures

### Identifying Issues
- **High polls/busy ratio**: Task doing very little work per poll, overhead heavy
- **High scheduled time**: Executor overloaded, too many tasks or blocking
- **Long-lived idle tasks**: Possible leaked tasks or forgotten futures
- **Many short-lived tasks**: Task spawn overhead, batch operations

### Resource View
- **Async ops**: Track I/O operations
- **Wakers**: Track how futures are woken (timer, I/O, explicit)
- High waker churn = potential busy-waiting or excessive notifications

## Combining Tools

### Typical Workflow
1. **Criterion**: Identify that performance regressed or is insufficient
2. **Flamegraph**: Identify hot functions (profiling with 99 Hz sampling)
3. **perf stat**: Determine if CPU, memory, or branch-bound
4. **Tokio console**: If async-heavy, check task/executor health
5. **Deep dive**: Use perf record + perf report for instruction-level detail

### Cross-Reference Signals
- Criterion shows regression + flamegraph shows alloc = allocation hot spot
- Low Criterion throughput + high perf cache misses = cache locality issue
- Tokio console high scheduled time + flamegraph shows lock = contention blocking executor
- High Criterion variance + perf shows branch misses = unpredictable code paths
