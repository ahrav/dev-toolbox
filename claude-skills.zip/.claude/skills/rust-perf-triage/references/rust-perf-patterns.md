# Rust Performance Bottleneck Patterns

## Allocation Hot Spots

### Vec/String Growth Pathologies
- **Repeated push without reserve**: Causes exponential reallocs. Profile shows many small memcpy calls in Vec growth.
- **Clone storms**: Excessive .clone() on String/Vec in loops. Look for 10%+ time in clone/memcpy in flamegraph.
- **String concatenation**: Using + operator in loops instead of String::with_capacity + push_str.
- **collect() without size_hint**: Iterator chains without proper size hints cause reallocs.

### Boxing and Indirection
- **Box<dyn Trait> in hot paths**: Virtual dispatch + allocation. Profile shows alloc/dealloc noise.
- **Arc clones in tight loops**: Atomic ref-count updates show as contention. Consider Rc or borrows.
- **Cow unnecessary clones**: Check if to_owned() is actually needed or if borrowed form works.

### Zero-Copy Violations
- **Bytes::copy_from_slice when Bytes::from works**: Look for unnecessary copies before network send.
- **Vec conversions**: to_vec() on slices that could use borrowed form.
- **String::from on static strings**: Use &'static str when possible.

## Lock Contention

### Mutex Patterns
- **Wide critical sections**: Mutex held across slow operations (I/O, syscalls). Profile shows high contention %.
- **False sharing**: Multiple Mutex on same cache line. Use cache-padded structures.
- **Mutex instead of RwLock**: Many readers blocked by single writer. RwLock can help if writes are rare.
- **Lock ordering issues**: Inconsistent lock acquisition order causes deadlock risk and contention.

### Async Lock Pitfalls
- **Holding tokio::sync::Mutex across .await**: Locks task scheduler, shows as blocking tasks in tokio-console.
- **Excessive parking/unparking**: Too fine-grained locks cause scheduler thrashing.

## Cache Efficiency

### Data Layout
- **Struct bloat**: Large structs cause cache line waste. Profile shows low IPC (instructions per cycle).
- **AoS vs SoA**: Array-of-Structs can be cache-hostile for columnar access. Consider Struct-of-Arrays.
- **Hot/cold field separation**: Frequently accessed fields mixed with rarely used. Split into hot/cold structs.
- **Alignment issues**: Unaligned access causes stalls. Use #[repr(C, align(64))] for cache-aligned types.

### Branch Prediction
- **Random branches in tight loops**: Profile shows high branch-mispredict rate (>5%).
- **Virtual dispatch in inner loops**: Use static dispatch (generics) or profile-guided optimization.
- **Complex conditionals**: Simplify hot path logic, push edge cases to cold paths.

### Prefetching
- **Sequential access breaks**: Scattered reads prevent prefetcher. Reorganize for sequential access.
- **Dependent loads**: Each load depends on previous result. Try to batch independent operations.

## Async Bottlenecks

### Runtime Overhead
- **Excessive task spawning**: Creating tasks has overhead. Profile shows tokio spawn noise.
- **Small async functions**: Async overhead exceeds work done. Make synchronous or batch.
- **Blocking in async**: Synchronous I/O or compute blocks executor. Use spawn_blocking.

### Contention Patterns
- **Single-threaded bottleneck**: All tasks contend for one resource. Shard or use lock-free structures.
- **Channel saturation**: Bounded channels full, tasks parking frequently.
- **Executor starvation**: Too many tasks on too few threads. Tune worker pool or use dedicated thread pools.

### Tokio-Specific
- **LocalSet unnecessary overhead**: Using LocalSet when multi-threaded runtime works.
- **select! bias**: select! has implicit priority order. Random order or fair select may help.
- **Timeout overhead**: Too many timeouts create timer pressure. Batch timeouts when possible.

## Memory Access Patterns

### NUMA Issues
- **Cross-socket access**: Memory allocated on wrong NUMA node. Use numactl or platform-specific pinning.
- **Thread migration**: OS moves threads between cores/sockets. Pin threads for sensitive workloads.

### TLB Pressure
- **Large page allocations**: Many small objects across many pages cause TLB thrashing.
- **Fragmentation**: Long-running services accumulate fragmentation. Consider arena allocation.

## Signal Phrases in Profiles

- "alloc" + "dealloc" hot: Allocation churn
- "memcpy" wide bar: Unnecessary copying
- "parking_lot" or "std::sync": Lock contention
- "clone" prominent: Clone overhead
- "drop" visible: Destructor cost (Arc, Vec)
- "tokio::task::spawn": Task overhead
- Low IPC (<1.0): Cache misses or branch mispredicts
- High cycle count on simple operations: False sharing or contention
