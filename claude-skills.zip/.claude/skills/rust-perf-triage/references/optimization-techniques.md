# Rust Optimization Techniques

## Build Flags and Compiler Options

### Release Profile Optimization
```toml
[profile.release]
opt-level = 3              # Maximum optimization
lto = "fat"                # Link-time optimization across all crates
codegen-units = 1          # Better optimization, slower compile
panic = "abort"            # Skip unwind tables
strip = true               # Remove debug symbols
```

### Target-Specific Tuning
```bash
# Native CPU features (x86-64-v3: AVX2, BMI, FMA)
RUSTFLAGS="-C target-cpu=native"

# Specific CPU generation
RUSTFLAGS="-C target-cpu=x86-64-v3"

# Enable specific features
RUSTFLAGS="-C target-feature=+avx2,+fma,+bmi2"
```

### Profile-Guided Optimization (PGO)
```toml
[profile.release]
# Step 1: Instrument
[profile.pgo-instrument]
inherits = "release"
# Outputs .profraw files

# Step 2: Optimize with profile data
[profile.pgo-optimize]
inherits = "release"
# RUSTFLAGS="-C profile-use=/path/to/merged.profdata"
```

### When to Use
- **lto = "fat"**: Production builds, +5-15% performance, 2-5x slower compile
- **codegen-units = 1**: Maximum single-threaded perf, slower compile
- **target-cpu=native**: Non-portable, best for server workloads
- **PGO**: 5-15% improvement on hot paths, requires representative workload

## Zero-Copy Patterns

### Bytes Crate
```rust
// Bad: Copy on every operation
let data = vec![0u8; 1024];
socket.send(&data).await?;

// Good: Zero-copy sharing
let data = Bytes::from(vec![0u8; 1024]);
socket.send(data.clone()).await?; // Cheap reference count
```

### Avoiding to_vec()
```rust
// Bad: Allocates new Vec
fn process_data(data: &[u8]) -> Vec<u8> {
    data.to_vec()
}

// Good: Return slice or Cow
fn process_data(data: &[u8]) -> &[u8] {
    data
}

// Good: Use Cow when modification is conditional
fn process_data(data: &[u8]) -> Cow<[u8]> {
    if needs_modification(data) {
        Cow::Owned(modify(data))
    } else {
        Cow::Borrowed(data)
    }
}
```

### mem::take and mem::replace
```rust
// Bad: Clone to extract from &mut
fn extract(item: &mut Option<Vec<u8>>) -> Vec<u8> {
    item.clone().unwrap()
}

// Good: Take ownership without clone
fn extract(item: &mut Option<Vec<u8>>) -> Vec<u8> {
    item.take().unwrap()  // Replaces with None
}

// Good: Replace with new value
let old_vec = mem::replace(&mut data.buffer, Vec::new());
```

## SIMD and Vectorization

### Auto-Vectorization
```rust
// Compiler can auto-vectorize simple loops
fn add_arrays(a: &[f32], b: &[f32], out: &mut [f32]) {
    for i in 0..a.len() {
        out[i] = a[i] + b[i];  // Vectorizes to SIMD
    }
}

// Check with: cargo asm --release your_crate::add_arrays
// Look for: vaddps, vmulps (AVX), or addps, mulps (SSE)
```

### Explicit SIMD with packed_simd
```rust
use packed_simd::f32x8;

fn dot_product_simd(a: &[f32], b: &[f32]) -> f32 {
    let mut sum = f32x8::splat(0.0);
    for i in (0..a.len()).step_by(8) {
        let va = f32x8::from_slice_unaligned(&a[i..]);
        let vb = f32x8::from_slice_unaligned(&b[i..]);
        sum += va * vb;
    }
    sum.sum()
}
```

### Rayon for Data Parallelism
```rust
use rayon::prelude::*;

// Bad: Sequential processing
let result: Vec<_> = data.iter().map(|x| expensive(x)).collect();

// Good: Parallel processing
let result: Vec<_> = data.par_iter().map(|x| expensive(x)).collect();
```

### When to Use
- **Auto-vectorization**: Free, works for simple loops on primitives
- **Explicit SIMD**: 2-4x improvement for math-heavy code, requires unsafe
- **Rayon**: Near-linear scaling for embarrassingly parallel work

## Allocation Reduction

### Pre-allocate with Capacity
```rust
// Bad: Reallocates multiple times
let mut v = Vec::new();
for i in 0..1000 {
    v.push(i);
}

// Good: Single allocation
let mut v = Vec::with_capacity(1000);
for i in 0..1000 {
    v.push(i);
}
```

### String Building
```rust
// Bad: Many allocations and copies
let mut s = String::new();
for i in 0..100 {
    s = s + &i.to_string();  // Allocates each time!
}

// Good: Pre-allocate and push
let mut s = String::with_capacity(300);
for i in 0..100 {
    s.push_str(&i.to_string());
}

// Better: Use format! with capacity estimate
let mut s = String::with_capacity(300);
for i in 0..100 {
    use std::fmt::Write;
    write!(&mut s, "{}", i).unwrap();
}
```

### Arena Allocation (bumpalo)
```rust
use bumpalo::Bump;

// For many small, short-lived allocations
let arena = Bump::new();
for _ in 0..10000 {
    let data = arena.alloc([0u8; 32]);
    process(data);
} // All freed together, very fast
```

### SmallVec for Stack Allocation
```rust
use smallvec::{SmallVec, smallvec};

// Bad: Heap allocates even for small vectors
let v: Vec<u32> = vec![1, 2, 3];

// Good: Stack-allocated for <= 8 elements
let v: SmallVec<[u32; 8]> = smallvec![1, 2, 3];
```

## Async Optimization

### Blocking vs Async
```rust
// Bad: Blocking I/O in async context
async fn handler() {
    let content = std::fs::read_to_string("file.txt").unwrap(); // Blocks executor!
}

// Good: Use spawn_blocking
async fn handler() {
    let content = tokio::task::spawn_blocking(|| {
        std::fs::read_to_string("file.txt").unwrap()
    }).await.unwrap();
}

// Good: Use async I/O
async fn handler() {
    let content = tokio::fs::read_to_string("file.txt").await.unwrap();
}
```

### Task Granularity
```rust
// Bad: Spawn task for tiny work
for item in items {
    tokio::spawn(async move {
        process_one(item).await  // Task overhead > work
    });
}

// Good: Batch work per task
for chunk in items.chunks(100) {
    let chunk = chunk.to_vec();
    tokio::spawn(async move {
        for item in chunk {
            process_one(item).await
        }
    });
}
```

### Avoiding Contention
```rust
// Bad: Single shared Mutex
lazy_static! {
    static ref CACHE: Mutex<HashMap<K, V>> = Mutex::new(HashMap::new());
}

// Good: Shard the cache
lazy_static! {
    static ref CACHE: [Mutex<HashMap<K, V>>; 16] = /* init 16 maps */;
}

fn get(key: K) -> Option<V> {
    let shard = hash(&key) % 16;
    CACHE[shard].lock().unwrap().get(&key).cloned()
}
```

### select! Optimization
```rust
// Bad: Biased select can starve branches
tokio::select! {
    _ = high_priority() => { /* runs first */ }
    _ = low_priority() => { /* may never run */ }
}

// Good: Random selection for fairness
tokio::select! {
    biased;  // Remove bias
    _ = high_priority() => {}
    _ = low_priority() => {}
}
```

## Lock-Free Structures

### Crossbeam for Concurrent Data Structures
```rust
use crossbeam::queue::SegQueue;

// Lock-free queue
static QUEUE: SegQueue<Work> = SegQueue::new();

// Push and pop without locks
QUEUE.push(work);
if let Some(work) = QUEUE.pop() {
    process(work);
}
```

### Atomic Operations
```rust
use std::sync::atomic::{AtomicU64, Ordering};

// Bad: Mutex for simple counter
let counter = Mutex::new(0u64);
*counter.lock().unwrap() += 1;

// Good: Atomic increment
let counter = AtomicU64::new(0);
counter.fetch_add(1, Ordering::Relaxed);
```

## Faster Hashing

### FxHash for Integer Keys
```rust
use rustc_hash::FxHashMap;

// Bad: Default SipHash for integer keys (cryptographic, slow)
let map: HashMap<u64, Value> = HashMap::new();

// Good: FxHash for non-cryptographic use (3-5x faster)
let map: FxHashMap<u64, Value> = FxHashMap::default();
```

### AHash for General Purpose
```rust
use ahash::AHashMap;

// Faster than SipHash, good DOS resistance
let map: AHashMap<String, Value> = AHashMap::new();
```

### When to Use
- **FxHash**: Integer keys, trusted input, max speed
- **AHash**: String keys, untrusted input, good balance
- **SipHash (default)**: Cryptographic hashing needed

## Cache-Friendly Data Layout

### Struct Packing
```rust
// Bad: 24 bytes due to padding
struct Item {
    flag: bool,     // 1 byte
    // 7 bytes padding
    count: u64,     // 8 bytes
    active: bool,   // 1 byte
    // 7 bytes padding
}

// Good: 10 bytes (or 16 with alignment)
#[repr(C)]
struct Item {
    count: u64,     // 8 bytes
    flag: bool,     // 1 byte
    active: bool,   // 1 byte
    // 6 bytes padding
}
```

### Cache Line Alignment
```rust
// Prevent false sharing
#[repr(align(64))]
struct CachePadded<T>(T);

// Use for frequently updated shared data
static COUNTERS: [CachePadded<AtomicU64>; 8] = /* ... */;
```

### Array-of-Structs vs Struct-of-Arrays
```rust
// Bad for sequential field access
struct AoS {
    items: Vec<Item>,  // Item { x: u32, y: u32, z: u32 }
}

// Good when accessing all x values
struct SoA {
    x: Vec<u32>,
    y: Vec<u32>,
    z: Vec<u32>,
}
```

## Measurement and Validation

### Adding Instrumentation
```rust
// Coarse timing
let start = std::time::Instant::now();
expensive_operation();
println!("Took: {:?}", start.elapsed());

// Fine-grained profiling hooks
#[cfg(feature = "profiling")]
puffin::profile_function!();
```

### Statistical Testing
```rust
// Use Criterion for A/B testing
use criterion::{black_box, criterion_group, criterion_main, Criterion};

fn bench_old(c: &mut Criterion) {
    c.bench_function("old_impl", |b| {
        b.iter(|| old_implementation(black_box(data)))
    });
}

fn bench_new(c: &mut Criterion) {
    c.bench_function("new_impl", |b| {
        b.iter(|| new_implementation(black_box(data)))
    });
}
```
