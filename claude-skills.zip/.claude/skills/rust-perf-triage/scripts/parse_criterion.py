#!/usr/bin/env python3
"""
Parse Criterion benchmark JSON output and extract key metrics.

Usage:
    python parse_criterion.py <criterion-json-file>
    python parse_criterion.py --compare old.json new.json
"""

import json
import sys
from pathlib import Path
from typing import Dict, List, Tuple


def parse_estimates(estimates: Dict) -> Dict[str, float]:
    """Extract mean, std dev, and confidence interval from estimates."""
    return {
        'mean': estimates['mean']['point_estimate'],
        'std_dev': estimates['std_dev']['point_estimate'],
        'median': estimates['median']['point_estimate'],
        'mean_lower': estimates['mean']['confidence_interval']['lower_bound'],
        'mean_upper': estimates['mean']['confidence_interval']['upper_bound'],
    }


def format_duration(nanos: float) -> str:
    """Format nanoseconds to human-readable duration."""
    if nanos < 1_000:
        return f"{nanos:.2f} ns"
    elif nanos < 1_000_000:
        return f"{nanos / 1_000:.2f} µs"
    elif nanos < 1_000_000_000:
        return f"{nanos / 1_000_000:.2f} ms"
    else:
        return f"{nanos / 1_000_000_000:.2f} s"


def parse_criterion_json(filepath: Path) -> Dict:
    """Parse a Criterion benchmark JSON file."""
    with open(filepath) as f:
        data = json.load(f)
    
    results = {}
    for benchmark in data.get('benchmarks', []):
        name = benchmark['name']
        estimates = parse_estimates(benchmark['estimates'])
        
        results[name] = {
            'mean': estimates['mean'],
            'std_dev': estimates['std_dev'],
            'median': estimates['median'],
            'mean_lower': estimates['mean_lower'],
            'mean_upper': estimates['mean_upper'],
            'mean_formatted': format_duration(estimates['mean']),
            'std_dev_pct': (estimates['std_dev'] / estimates['mean'] * 100),
        }
        
        # Add throughput if available
        if 'throughput' in benchmark:
            tp = benchmark['throughput']
            results[name]['throughput'] = {
                'bytes': tp.get('bytes', 0),
                'elements': tp.get('elements', 0),
            }
    
    return results


def compare_results(old: Dict, new: Dict) -> List[Tuple[str, Dict]]:
    """Compare two benchmark results and compute changes."""
    comparisons = []
    
    for name in sorted(set(old.keys()) | set(new.keys())):
        if name not in old:
            comparisons.append((name, {'status': 'NEW', 'new_mean': new[name]['mean']}))
        elif name not in new:
            comparisons.append((name, {'status': 'REMOVED', 'old_mean': old[name]['mean']}))
        else:
            old_mean = old[name]['mean']
            new_mean = new[name]['mean']
            change_pct = ((new_mean - old_mean) / old_mean) * 100
            
            comparisons.append((name, {
                'status': 'CHANGED',
                'old_mean': old_mean,
                'new_mean': new_mean,
                'change_pct': change_pct,
                'old_formatted': old[name]['mean_formatted'],
                'new_formatted': new[name]['mean_formatted'],
            }))
    
    return comparisons


def print_single_result(results: Dict):
    """Print results from a single benchmark run."""
    print("\n=== Criterion Benchmark Results ===\n")
    
    for name, metrics in sorted(results.items()):
        print(f"Benchmark: {name}")
        print(f"  Mean:    {metrics['mean_formatted']}")
        print(f"  Std Dev: {metrics['std_dev_pct']:.2f}%")
        print(f"  CI:      [{format_duration(metrics['mean_lower'])}, {format_duration(metrics['mean_upper'])}]")
        
        if 'throughput' in metrics:
            if metrics['throughput']['bytes'] > 0:
                mb_per_sec = (metrics['throughput']['bytes'] / metrics['mean']) * 1_000
                print(f"  Throughput: {mb_per_sec:.2f} MB/s")
            if metrics['throughput']['elements'] > 0:
                ops_per_sec = 1_000_000_000 / metrics['mean']
                print(f"  Throughput: {ops_per_sec:.2f} ops/s")
        
        print()


def print_comparison(comparisons: List[Tuple[str, Dict]]):
    """Print comparison between two benchmark runs."""
    print("\n=== Criterion Benchmark Comparison ===\n")
    
    regressions = []
    improvements = []
    unchanged = []
    
    for name, comp in comparisons:
        if comp['status'] == 'NEW':
            print(f"[NEW] {name}: {format_duration(comp['new_mean'])}")
        elif comp['status'] == 'REMOVED':
            print(f"[REMOVED] {name}: {format_duration(comp['old_mean'])}")
        else:
            change = comp['change_pct']
            symbol = "🔴" if change > 0 else "🟢" if change < -2 else "⚪"
            print(f"{symbol} {name}")
            print(f"    Old: {comp['old_formatted']}")
            print(f"    New: {comp['new_formatted']}")
            print(f"    Change: {change:+.2f}%")
            print()
            
            if change > 5:
                regressions.append((name, change))
            elif change < -5:
                improvements.append((name, change))
            else:
                unchanged.append(name)
    
    print("\n=== Summary ===")
    print(f"Regressions (>5% slower): {len(regressions)}")
    for name, change in sorted(regressions, key=lambda x: x[1], reverse=True):
        print(f"  {name}: {change:+.2f}%")
    
    print(f"\nImprovements (>5% faster): {len(improvements)}")
    for name, change in sorted(improvements, key=lambda x: x[1]):
        print(f"  {name}: {change:+.2f}%")
    
    print(f"\nUnchanged (<5% diff): {len(unchanged)}")


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    
    if sys.argv[1] == '--compare':
        if len(sys.argv) != 4:
            print(__doc__)
            sys.exit(1)
        
        old_results = parse_criterion_json(Path(sys.argv[2]))
        new_results = parse_criterion_json(Path(sys.argv[3]))
        comparisons = compare_results(old_results, new_results)
        print_comparison(comparisons)
    else:
        results = parse_criterion_json(Path(sys.argv[1]))
        print_single_result(results)


if __name__ == '__main__':
    main()
