#!/bin/bash
# Run perf with common counter sets for Rust performance analysis
#
# Usage:
#   ./perf_counters.sh <preset> <command> [args...]
#
# Presets:
#   basic    - Core metrics: cycles, instructions, IPC
#   memory   - Cache and memory hierarchy
#   branch   - Branch prediction analysis
#   tlb      - TLB miss analysis
#   all      - Comprehensive counter set

set -euo pipefail

PRESET="${1:-}"
shift || true

if [ -z "$PRESET" ] || [ $# -eq 0 ]; then
    cat << EOF
Usage: $0 <preset> <command> [args...]

Presets:
  basic    - Core metrics: cycles, instructions, IPC
  memory   - Cache and memory hierarchy
  branch   - Branch prediction analysis  
  tlb      - TLB miss analysis
  all      - Comprehensive counter set

Examples:
  $0 basic ./target/release/my-app
  $0 memory cargo bench --bench my_benchmark
  $0 all ./target/release/my-app -- --workload-size 10000

EOF
    exit 1
fi

# Check if perf is available
if ! command -v perf &> /dev/null; then
    echo "Error: perf not found. Install with: apt-get install linux-perf"
    exit 1
fi

case "$PRESET" in
    basic)
        COUNTERS="cycles,instructions,cache-references,cache-misses,branches,branch-misses"
        ;;
    
    memory)
        COUNTERS="L1-dcache-loads,L1-dcache-load-misses,L1-dcache-stores,L1-dcache-store-misses,LLC-loads,LLC-load-misses,LLC-stores,LLC-store-misses"
        ;;
    
    branch)
        COUNTERS="branches,branch-misses,branch-load-misses,branch-loads"
        ;;
    
    tlb)
        COUNTERS="dTLB-loads,dTLB-load-misses,dTLB-stores,dTLB-store-misses,iTLB-loads,iTLB-load-misses"
        ;;
    
    all)
        COUNTERS="cycles,instructions,cache-references,cache-misses,branches,branch-misses,L1-dcache-loads,L1-dcache-load-misses,LLC-loads,LLC-load-misses,dTLB-loads,dTLB-load-misses"
        ;;
    
    *)
        echo "Error: Unknown preset '$PRESET'"
        exit 1
        ;;
esac

echo "=== Running perf with preset: $PRESET ==="
echo "Counters: $COUNTERS"
echo "Command: $*"
echo

perf stat -e "$COUNTERS" "$@" 2>&1 | tee perf-stat.log

echo
echo "=== Analysis ==="

# Parse output and compute derived metrics
if [ "$PRESET" = "basic" ] || [ "$PRESET" = "all" ]; then
    echo
    echo "Core Metrics:"
    grep -E "cycles|instructions" perf-stat.log | while read -r line; do
        echo "  $line"
    done
    
    CYCLES=$(grep "cycles" perf-stat.log | awk '{print $1}' | tr -d ',')
    INSTRUCTIONS=$(grep "instructions" perf-stat.log | awk '{print $1}' | tr -d ',')
    
    if [ -n "$CYCLES" ] && [ -n "$INSTRUCTIONS" ]; then
        IPC=$(awk "BEGIN {printf \"%.2f\", $INSTRUCTIONS / $CYCLES}")
        echo "  IPC (instructions per cycle): $IPC"
        
        if (( $(awk "BEGIN {print ($IPC < 1.0)}") )); then
            echo "  ⚠️  Low IPC (<1.0) suggests memory or cache bottleneck"
        elif (( $(awk "BEGIN {print ($IPC > 1.5)}") )); then
            echo "  ✓ Good IPC (>1.5) - CPU-bound workload"
        fi
    fi
    
    echo
    echo "Cache Metrics:"
    CACHE_REFS=$(grep "cache-references" perf-stat.log | awk '{print $1}' | tr -d ',')
    CACHE_MISSES=$(grep "cache-misses" perf-stat.log | awk '{print $1}' | tr -d ',')
    
    if [ -n "$CACHE_REFS" ] && [ -n "$CACHE_MISSES" ]; then
        MISS_RATE=$(awk "BEGIN {printf \"%.2f\", ($CACHE_MISSES / $CACHE_REFS) * 100}")
        echo "  Cache miss rate: $MISS_RATE%"
        
        if (( $(awk "BEGIN {print ($MISS_RATE > 10)}") )); then
            echo "  ⚠️  High cache miss rate (>10%) - consider data locality improvements"
        elif (( $(awk "BEGIN {print ($MISS_RATE < 3)}") )); then
            echo "  ✓ Low cache miss rate (<3%) - good locality"
        fi
    fi
    
    echo
    echo "Branch Metrics:"
    BRANCHES=$(grep "^[[:space:]]*[0-9,]*[[:space:]]*branches" perf-stat.log | awk '{print $1}' | tr -d ',')
    BRANCH_MISSES=$(grep "branch-misses" perf-stat.log | awk '{print $1}' | tr -d ',')
    
    if [ -n "$BRANCHES" ] && [ -n "$BRANCH_MISSES" ]; then
        BRANCH_MISS_RATE=$(awk "BEGIN {printf \"%.2f\", ($BRANCH_MISSES / $BRANCHES) * 100}")
        echo "  Branch miss rate: $BRANCH_MISS_RATE%"
        
        if (( $(awk "BEGIN {print ($BRANCH_MISS_RATE > 5)}") )); then
            echo "  ⚠️  High branch miss rate (>5%) - unpredictable control flow"
        elif (( $(awk "BEGIN {print ($BRANCH_MISS_RATE < 2)}") )); then
            echo "  ✓ Low branch miss rate (<2%) - predictable branches"
        fi
    fi
fi

if [ "$PRESET" = "memory" ]; then
    echo
    echo "L1 Data Cache:"
    L1_LOADS=$(grep "L1-dcache-loads" perf-stat.log | awk '{print $1}' | tr -d ',')
    L1_LOAD_MISSES=$(grep "L1-dcache-load-misses" perf-stat.log | awk '{print $1}' | tr -d ',')
    
    if [ -n "$L1_LOADS" ] && [ -n "$L1_LOAD_MISSES" ]; then
        L1_MISS_RATE=$(awk "BEGIN {printf \"%.2f\", ($L1_LOAD_MISSES / $L1_LOADS) * 100}")
        echo "  L1 miss rate: $L1_MISS_RATE%"
    fi
    
    echo
    echo "LLC (Last Level Cache):"
    LLC_LOADS=$(grep "LLC-loads" perf-stat.log | awk '{print $1}' | tr -d ',')
    LLC_LOAD_MISSES=$(grep "LLC-load-misses" perf-stat.log | awk '{print $1}' | tr -d ',')
    
    if [ -n "$LLC_LOADS" ] && [ -n "$LLC_LOAD_MISSES" ]; then
        LLC_MISS_RATE=$(awk "BEGIN {printf \"%.2f\", ($LLC_LOAD_MISSES / $LLC_LOADS) * 100}")
        echo "  LLC miss rate: $LLC_MISS_RATE%"
        
        if (( $(awk "BEGIN {print ($LLC_MISS_RATE > 20)}") )); then
            echo "  ⚠️  High LLC miss rate (>20%) - working set exceeds cache"
        fi
    fi
fi

if [ "$PRESET" = "tlb" ]; then
    echo
    echo "TLB Analysis:"
    DTLB_LOADS=$(grep "dTLB-loads" perf-stat.log | awk '{print $1}' | tr -d ',')
    DTLB_MISSES=$(grep "dTLB-load-misses" perf-stat.log | awk '{print $1}' | tr -d ',')
    
    if [ -n "$DTLB_LOADS" ] && [ -n "$DTLB_MISSES" ]; then
        DTLB_MISS_RATE=$(awk "BEGIN {printf \"%.2f\", ($DTLB_MISSES / $DTLB_LOADS) * 100}")
        echo "  Data TLB miss rate: $DTLB_MISS_RATE%"
        
        if (( $(awk "BEGIN {print ($DTLB_MISS_RATE > 5)}") )); then
            echo "  ⚠️  High dTLB miss rate (>5%) - TLB pressure from many pages"
        fi
    fi
    
    ITLB_LOADS=$(grep "iTLB-loads" perf-stat.log | awk '{print $1}' | tr -d ',')
    ITLB_MISSES=$(grep "iTLB-load-misses" perf-stat.log | awk '{print $1}' | tr -d ',')
    
    if [ -n "$ITLB_LOADS" ] && [ -n "$ITLB_MISSES" ]; then
        ITLB_MISS_RATE=$(awk "BEGIN {printf \"%.2f\", ($ITLB_MISSES / $ITLB_LOADS) * 100}")
        echo "  Instruction TLB miss rate: $ITLB_MISS_RATE%"
    fi
fi

echo
echo "Full output saved to: perf-stat.log"
