#!/usr/bin/env python3
"""
Generate validation probes for identified performance hotspots.

This script creates:
- Perf counter collection commands
- Microbenchmark harness templates
- NUMA validation scripts
- Storage/network sanity checks
- Compiler flag recommendations
"""

import argparse
import json
from pathlib import Path
from typing import List, Dict, Any


def generate_perf_counters(hotspots: List[Dict[str, Any]]) -> str:
    """Generate perf stat commands for relevant counters."""
    
    # Determine which counters to track based on hotspot categories
    categories = {hs.get('category', '') for hs in hotspots}
    
    counters = ['cycles', 'instructions']
    
    if any(cat in categories for cat in ['Data Layout and Locality', 'Memory Ordering and Atomics']):
        counters.extend(['L1-dcache-load-misses', 'L1-dcache-loads', 
                        'LLC-load-misses', 'LLC-loads'])
    
    if 'Branch Predictability' in categories:
        counters.extend(['branch-misses', 'branches'])
    
    if any(cat in categories for cat in ['TLB and Page Behavior', 'NUMA Locality']):
        counters.extend(['dTLB-load-misses', 'dTLB-loads'])
    
    if 'I-cache and Code Layout' in categories:
        counters.extend(['L1-icache-load-misses'])
    
    if any(cat in categories for cat in ['Syscalls and Context Switches', 'Scheduler and Async Runtime Behavior']):
        counters.append('context-switches')
    
    counter_str = ','.join(counters)
    
    return f"""# Perf Counter Collection
# Run your benchmark with these counters to validate findings

perf stat -e {counter_str} -- ./target/release/your-benchmark

# For more detailed analysis with per-function breakdown:
perf record -e cycles,instructions -g -- ./target/release/your-benchmark
perf report
"""


def generate_microbench_template(hotspot: Dict[str, Any]) -> str:
    """Generate criterion benchmark template for a specific hotspot."""
    
    location = hotspot.get('location', 'unknown')
    function = location.split('::')[-1] if '::' in location else 'function'
    category = hotspot.get('category', 'unknown')
    
    return f"""// Criterion microbenchmark for: {location}
// Category: {category}

use criterion::{{black_box, criterion_group, criterion_main, Criterion}};

fn bench_{function}(c: &mut Criterion) {{
    // TODO: Set up stable input data
    let input = vec![/* stable test data */];
    
    c.bench_function("{function}", |b| {{
        b.iter(|| {{
            // TODO: Call the function being tested
            // black_box(your_function(black_box(&input)))
        }})
    }});
}}

criterion_group!(benches, bench_{function});
criterion_main!(benches);

// Add to Cargo.toml:
// [[bench]]
// name = "bench_{function}"
// harness = false
//
// [dependencies]
// criterion = "0.5"
"""


def generate_numa_script(hotspots: List[Dict[str, Any]]) -> str:
    """Generate NUMA validation script."""
    
    has_numa_issues = any('NUMA' in hs.get('category', '') for hs in hotspots)
    
    if not has_numa_issues:
        return "# No NUMA-related hotspots identified"
    
    return """#!/bin/bash
# NUMA Validation Script

# Check NUMA topology
echo "=== NUMA Topology ==="
numactl --hardware

# Check current thread binding
echo -e "\\n=== Thread Binding ==="
ps -eLo pid,tid,psr,comm | grep your-process-name

# Run with explicit NUMA node binding
echo -e "\\n=== Running with NUMA node 0 binding ==="
numactl --cpunodebind=0 --membind=0 ./target/release/your-benchmark

# Run with interleave policy
echo -e "\\n=== Running with memory interleave ==="
numactl --interleave=all ./target/release/your-benchmark

# Monitor NUMA stats during execution
echo -e "\\n=== NUMA Stats (run in separate terminal) ==="
echo "numastat -c your-process-name 1"

# For thread pinning in Rust, use core_affinity crate:
# cargo add core_affinity
"""


def generate_storage_network_checks(hotspots: List[Dict[str, Any]]) -> str:
    """Generate storage and network sanity checks."""
    
    categories = {hs.get('category', '') for hs in hotspots}
    checks = []
    
    if 'Storage Queue Depth' in str(categories) or 'I/O' in str(categories):
        checks.append("""# Storage Checks
# Check current queue depth
cat /sys/block/nvme0n1/queue/nr_requests

# Check alignment
blockdev --getalignment /dev/nvme0n1
blockdev --getpbsz /dev/nvme0n1  # Physical block size

# Monitor I/O stats
iostat -x 1

# For async I/O in Rust, consider:
# - tokio-uring for io_uring support
# - Check that io_uring is properly configured
""")
    
    if 'Networking' in str(categories):
        checks.append("""# Network Checks
# Check NIC offloads
ethtool -k eth0 | grep -E "tcp-segmentation-offload|generic-segmentation-offload|rx-checksumming|tx-checksumming"

# Enable offloads if disabled
# sudo ethtool -K eth0 tso on gso on

# Check TLS session resumption
# openssl s_client -connect your-server:443 -reconnect

# Monitor network stats
sar -n DEV 1

# Check ring buffer sizes
ethtool -g eth0
""")
    
    return '\n'.join(checks) if checks else "# No storage/network hotspots identified"


def generate_compiler_flags(hotspots: List[Dict[str, Any]]) -> str:
    """Generate compiler flag recommendations."""
    
    categories = {hs.get('category', '') for hs in hotspots}
    
    flags = {
        'rustflags': [],
        'profile': {}
    }
    
    # Always recommend these for performance builds
    flags['profile'] = {
        'opt-level': 3,
        'lto': 'thin',
        'codegen-units': 1,
    }
    
    if any('Build and Codegen' in cat for cat in categories):
        flags['rustflags'].append('-C target-cpu=native')
    
    if any('SIMD' in cat for cat in categories):
        flags['rustflags'].append('-C target-feature=+avx2')
    
    if any('latency' in str(hotspots).lower() or 'panic' in str(hotspots).lower()):
        flags['profile']['panic'] = 'abort'
    
    rustflags_str = ' '.join(flags['rustflags'])
    
    return f"""# Compiler Configuration Recommendations

## Add to .cargo/config.toml:
[build]
rustflags = [{', '.join(f'"{f}"' for f in flags['rustflags'])}]

## Add to Cargo.toml:
[profile.release]
opt-level = {flags['profile']['opt-level']}
lto = "{flags['profile']['lto']}"
codegen-units = {flags['profile']['codegen-units']}
{'panic = "abort"' if flags['profile'].get('panic') == 'abort' else ''}

## For PGO (Profile-Guided Optimization):
# 1. Build with instrumentation:
#    RUSTFLAGS="-C profile-generate=/tmp/pgo-data" cargo build --release
# 2. Run representative workload
# 3. Rebuild with profile:
#    RUSTFLAGS="-C profile-use=/tmp/pgo-data/merged.profdata" cargo build --release

## Check what flags are actually being used:
cargo rustc --release -- --print cfg
"""


def main():
    parser = argparse.ArgumentParser(
        description='Generate validation probes for performance hotspots'
    )
    parser.add_argument(
        'hotspots_json',
        help='Path to JSON file with hotspot analysis results'
    )
    parser.add_argument(
        '-o', '--output-dir',
        default='validation_probes',
        help='Output directory for generated probes'
    )
    
    args = parser.parse_args()
    
    # Load hotspots
    with open(args.hotspots_json) as f:
        data = json.load(f)
        hotspots = data.get('hotspots', [])
    
    # Create output directory
    output_dir = Path(args.output_dir)
    output_dir.mkdir(exist_ok=True)
    
    # Generate perf counters
    (output_dir / 'perf_counters.sh').write_text(
        generate_perf_counters(hotspots)
    )
    
    # Generate microbench templates for top N hotspots
    for i, hotspot in enumerate(hotspots[:5], 1):
        bench_file = output_dir / f'bench_{i}.rs'
        bench_file.write_text(generate_microbench_template(hotspot))
    
    # Generate NUMA script
    (output_dir / 'numa_validation.sh').write_text(
        generate_numa_script(hotspots)
    )
    
    # Generate storage/network checks
    (output_dir / 'storage_network_checks.sh').write_text(
        generate_storage_network_checks(hotspots)
    )
    
    # Generate compiler flags
    (output_dir / 'compiler_flags.txt').write_text(
        generate_compiler_flags(hotspots)
    )
    
    print(f"✅ Generated validation probes in {output_dir}/")
    print(f"   - perf_counters.sh")
    print(f"   - bench_*.rs (microbenchmark templates)")
    print(f"   - numa_validation.sh")
    print(f"   - storage_network_checks.sh")
    print(f"   - compiler_flags.txt")


if __name__ == '__main__':
    main()
