---
name: rust-hotspot-finder
description: Find likely performance hotspots in Rust code before profiling. Classify findings by risk, impact, and ease of fix. Propose concrete refactors with diffs and emit validation probes for follow-on performance triage. Use when asked to scan code for hotspots, identify O(n²) loops, flag false sharing, suggest SIMD opportunities, find allocation churn, review for contention, predict bottlenecks, or analyze performance of Rust systems at scale (e.g., 500k+ RPS, 11 PB/day workloads).
---

# Rust Hotspot Finder

Static and heuristic analysis skill for identifying performance bottlenecks in Rust code before running profilers. Analyzes code structure, data flow, and usage patterns to predict likely hotspots, then ranks findings by potential impact and remediation effort.

## When to Use This Skill

This skill triggers on requests to:
- Scan code for performance hotspots before profiling
- Identify algorithmic issues (O(n²) loops, redundant work)
- Flag concurrency problems (false sharing, lock contention)
- Find allocation and copy opportunities
- Suggest SIMD or branchless optimizations
- Review async/await patterns for efficiency
- Predict bottlenecks given a design document and expected load
- Analyze high-scale systems (100k+ RPS, petabyte-scale data)

## Core Workflow

### 1. Gather Context

Collect information needed for analysis:
- **Code**: Repository path, specific files, or code snippets
- **Workload**: Expected RPS, data sizes, latency requirements
- **Environment**: CPU architecture, core count, memory topology (NUMA?)
- **Build config**: Cargo.toml profiles, RUSTFLAGS, target features
- **Known constraints**: Latency SLOs, throughput goals, resource limits

If the user hasn't provided workload details, infer from context (e.g., "media delivery at 11B req/day" → ~130k RPS average, likely much higher peak).

### 2. Load Reference Materials

Read the taxonomy and checks:
- `references/taxonomy.md`: Performance category definitions
- `references/static-checks.md`: Specific patterns to identify

These files contain the detailed knowledge for classification and detection.

### 3. Analyze the Code

Perform static analysis in order of likely impact:

#### A. Algorithmic Analysis
Scan for computational complexity issues:
- Nested loops that are quadratic or worse
- Redundant computation (same work repeated)
- Missing memoization or caching opportunities
- Inefficient algorithms where better alternatives exist

#### B. Memory and Data Layout
Check access patterns and allocation:
- Clone/Arc::clone in loops
- Vec growth without `with_capacity()`
- String formatting (`format!`, `to_string()`) in hot paths
- AoS vs SoA layout issues
- False sharing risks (adjacent fields accessed by different threads)
- Missing alignment for SIMD

#### C. Concurrency Patterns
Look for synchronization issues:
- Locks held across I/O or await points
- Spawn-per-item patterns
- Tiny or unbounded channels
- Unsharded shared state
- Atomics with overly strong ordering

#### D. I/O and Async
Identify I/O inefficiencies:
- Small reads/writes in loops
- Blocking in async context
- Missing buffering or batching
- Poor queue depths for storage/network

#### E. Hot Path Code Generation
Check build and codegen concerns:
- Missing `target-cpu=native` or feature flags
- No LTO or high codegen-units
- Cold code inlined into hot paths
- Monomorphization explosion

For each finding, identify:
- **Category**: From taxonomy (e.g., "Allocations and Copies")
- **Location**: File, function, line number
- **Pattern**: Specific anti-pattern detected
- **Risk**: How likely this is hot (Low/Medium/High)
- **Impact**: Estimated speedup if fixed (Low/Medium/High)
- **Effort**: Code change complexity (Low/Medium/High)

### 4. Generate Fixes

For each hotspot, propose concrete remediation:
- **Explanation**: Why this is a problem
- **Suggested fix**: Specific code change
- **Diff**: Show before/after if the change is localized
- **Trade-offs**: Any downsides (complexity, readability, safety)

Prioritize fixes by **impact/effort ratio** - high-impact, low-effort changes first.

### 5. Emit Validation Probes

Generate artifacts for follow-up validation:
- Perf counter collection commands
- Microbenchmark harness templates (Criterion)
- NUMA validation scripts (if relevant)
- Storage/network sanity checks (if relevant)
- Compiler flag recommendations

Use `scripts/generate_probes.py` to automate probe generation. This script takes hotspot findings in JSON format and creates validation artifacts.

### 6. Format the Report

Structure output as a prioritized report:

```
# Performance Hotspot Analysis Report

## Executive Summary
- Total hotspots identified: N
- High-impact opportunities: N
- Est. aggregate speedup potential: X-Yx (range)

## Top Priority Hotspots

### 1. [Category]: [Brief description]
**Location**: src/path/file.rs:123 in `function_name()`
**Risk**: High | **Impact**: High | **Effort**: Low
**Score**: 9/10 (impact/effort)

**Issue**: [Explain what's wrong]

**Current code**:
```rust
// Show problematic code
```

**Suggested fix**:
```rust
// Show improved code
```

**Expected improvement**: 2-3x faster based on [reasoning]

**Validation**: [Reference probe or benchmark]

[Repeat for each hotspot, sorted by priority score]

## Validation Artifacts

Generated probes for follow-up testing:
- Perf counter collection: [location]
- Microbenchmarks: [location]
- Configuration checks: [location]

## Build Configuration Recommendations

[Compiler flags, Cargo.toml changes, RUSTFLAGS]
```

## Analysis Strategies by Request Type

### "Scan this crate for hotspots"
1. Start with entry points (main, request handlers)
2. Trace hot paths (most frequent execution routes)
3. Check loops and inner functions
4. Review allocations and conversions
5. Inspect concurrency primitives
6. Generate comprehensive report

### "Identify O(n²) loops"
Focus algorithmic analysis:
- Find nested loops over collections
- Check if inner loop size depends on outer iterator
- Look for repeated scans, nested contains/find
- Suggest alternatives (HashMap, sorted Vec with binary search, index-based access)

### "Flag false sharing"
Focus memory topology:
- Find structs with fields updated by different threads
- Check for adjacent AtomicUsize or Mutex fields
- Look for array-of-atomics patterns
- Suggest padding to separate cache lines

### "Show where SIMD applies"
Focus vectorization opportunities:
- Find loops over numeric arrays
- Check for element-wise operations
- Identify reduction operations (sum, min/max)
- Look for missing alignment
- Sketch std::simd refactor or suggest packed_simd

### "Find allocation churn"
Focus memory allocation:
- Trace Vec/String/Box creation in loops
- Find temporary allocations that could be reused
- Check for collect() → iterate patterns
- Suggest arenas, object pools, or `with_capacity()`

### "Predict bottlenecks for 500k RPS"
Work backward from requirements:
- Calculate per-request budget (2μs at 500k RPS)
- Identify operations that could exceed budget
- Check for synchronization that doesn't scale
- Model memory bandwidth needs
- Estimate cache pressure
- Flag anything incompatible with target load

## Scoring Rubric

**Risk** (likelihood this path is hot):
- **High**: In inner loop, per-request path, or called >1000x/sec
- **Medium**: On common path but not inner loop, called 10-1000x/sec
- **Low**: Edge case, error path, or infrequent operation

**Impact** (estimated speedup):
- **High**: 2x+ expected improvement, or removes major bottleneck
- **Medium**: 20-100% improvement
- **Low**: <20% improvement, or reduces variance

**Effort** (change complexity):
- **Low**: Localized fix, <50 lines changed, low regression risk
- **Medium**: 50-200 lines, requires some restructuring
- **High**: >200 lines, architectural change, significant testing needed

**Priority Score**: Impact (1-3) × 3 + Risk (1-3) - Effort (1-3)
Sort hotspots by this score descending.

## Tips for Effective Analysis

1. **Start broad, then focus**: Scan entire codebase first, then drill into top hotspots
2. **Consider the workload**: Same code can be hot at high RPS, cold at low RPS
3. **Think about the data**: Large data changes everything - algorithms, caching, I/O
4. **Check the build**: Many issues are from missing compiler flags
5. **Validate assumptions**: Always emit probes for user to measure actual impact
6. **Be specific**: Generic advice doesn't help - show exact code changes
7. **Explain trade-offs**: Faster isn't always better if it adds complexity or reduces safety

## Common Pitfalls to Avoid

- Don't flag every clone - many are fine and cheap
- Don't suggest unsafe code without explicitly discussing safety
- Don't over-optimize cold paths
- Don't recommend obscure crates without justification
- Don't promise exact speedup numbers without measurements
- Don't ignore readability in pursuit of micro-optimizations

## Output Format

Always produce:
1. **Prioritized hotspot list** with code locations and fixes
2. **Validation probes** for testing (via generate_probes.py)
3. **Build configuration** recommendations
4. **Summary** with estimated aggregate impact

Optionally include:
- **Visualization**: Call graphs, flame graph predictions, data flow diagrams
- **Comparisons**: Alternative approaches with trade-off analysis
- **Long-term recommendations**: Architectural changes for future consideration
