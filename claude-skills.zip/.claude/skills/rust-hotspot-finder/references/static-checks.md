# Static Performance Checks

Concrete patterns and anti-patterns to identify in Rust code. Each check includes the pattern to detect, why it matters, and typical remediation.

## Hot Loop Checks

### Clone in Tight Loops
**Pattern**: `.clone()` or `Arc::clone()` inside loop bodies, especially on non-trivial types.
**Impact**: Allocation and memory traffic per iteration.
**Fix**: Clone outside loop if possible, use references, or switch to `Rc`/`Arc` if sharing is rare.

### String Formatting and Allocation
**Pattern**: `format!()`, `.to_string()`, `String::from()` in hot paths.
**Impact**: Allocation per call, repeated formatting work.
**Fix**: Pre-allocate with `String::with_capacity()`, reuse buffers, use `write!()` to append, or format once and reuse.

### Collect-Then-Iterate
**Pattern**: `.collect::<Vec<_>>()` immediately followed by iteration or single use.
**Impact**: Unnecessary allocation and copy.
**Fix**: Chain iterator operations directly, or use `.for_each()`.

### HashMap Operations in Inner Loops
**Pattern**: Frequent `insert`, `get`, or `remove` on `HashMap`/`BTreeMap` inside tight loops.
**Impact**: Hashing overhead, cache misses, reallocation.
**Fix**: Batch operations, use `entry` API, pre-size with `with_capacity()`, or consider `Vec` with binary search for small key sets.

### Small Vec Growth
**Pattern**: `Vec::new()` or `vec![]` growing incrementally in loops without `with_capacity()`.
**Impact**: Multiple reallocations and copies.
**Fix**: Use `Vec::with_capacity(n)` when size is known or estimable.

## Concurrency Checks

### Mutex/RwLock Across I/O
**Pattern**: Holding `Mutex` or `RwLock` guard during I/O operations, network calls, or file access.
**Impact**: Lock held during slow operation blocks other threads.
**Fix**: Extract data under lock, release, then do I/O. Or use message passing.

### Await Inside Critical Sections
**Pattern**: `.await` while holding mutex guard or other synchronization primitive.
**Impact**: Holds lock across async suspension, blocking other tasks.
**Fix**: Drop guard before await, restructure to hold lock only for data access.

### Spawn-Per-Item
**Pattern**: `tokio::spawn()` or `thread::spawn()` for each work item in a loop.
**Impact**: Thread/task creation overhead, scheduler pressure.
**Fix**: Use thread pool, bounded task spawning, or structured concurrency with `join_set`.

### Tiny or Unbounded Channels
**Pattern**: Channel with capacity 1 in high-throughput paths, or unbounded channels without backpressure.
**Impact**: Contention on tiny channels, memory growth on unbounded ones.
**Fix**: Tune channel size to workload, add backpressure or rate limiting.

### Global Shared Mutables
**Pattern**: `static mut`, `lazy_static` with `Mutex`, or thread-shared `Arc<Mutex<T>>` accessed frequently.
**Impact**: Cache line bouncing, lock contention, false sharing.
**Fix**: Thread-local storage, sharded locks, or message passing.

## Dispatch and Layout Checks

### Trait Objects in Inner Loops
**Pattern**: `dyn Trait` calls in tight loops where concrete type is known or limited.
**Impact**: Indirect call overhead, missed inlining and optimization.
**Fix**: Use generics with monomorphization, enum dispatch, or hoist dynamic dispatch outside loop.

### Large Enums in Hot Paths
**Pattern**: Enums with large variants processed frequently, especially with size mismatches.
**Impact**: Copying large values, cache pollution from unused variant data.
**Fix**: Box large variants, split into smaller enums, or use indirection.

### Array-of-Structs (AoS) Where SoA Fits
**Pattern**: `Vec<Struct>` where only a few fields are accessed together.
**Impact**: Poor cache utilization, loading unused data.
**Fix**: Restructure to struct-of-arrays (SoA) for better data locality.

### Strided Access Patterns
**Pattern**: Accessing every nth element in arrays or jumping large strides.
**Impact**: Cache line misses, TLB pressure, prefetcher inefficiency.
**Fix**: Reorder data for sequential access, tile/block processing, or gather-scatter with SIMD.

### Dynamic Dispatch in Hot Paths
**Pattern**: Virtual calls or trait object indirection in performance-critical loops.
**Impact**: Prevents inlining, adds indirection cost.
**Fix**: Monomorphization, enum-based dispatch, or caching dispatch results.

## I/O and Syscall Checks

### Small Reads/Writes in Loops
**Pattern**: Single-byte or small buffer I/O operations repeated in loops.
**Impact**: Syscall overhead, context switches, poor throughput.
**Fix**: Buffer with `BufReader`/`BufWriter`, batch operations, or use vectored I/O.

### Frequent Flush or Fsync
**Pattern**: Explicit `flush()` or `sync_all()` after each write operation.
**Impact**: Forces slow disk operations, defeats write caching.
**Fix**: Batch writes, flush only at transaction boundaries, or use async I/O with grouping.

### Per-Message TLS Handshake
**Pattern**: New TLS connection for each request or message.
**Impact**: Handshake latency and cryptographic overhead.
**Fix**: Connection pooling, TLS session resumption, or persistent connections.

### Per-Row Serialization
**Pattern**: `serde_json::to_string()` or similar for each row in a batch.
**Impact**: Repeated serialization overhead, allocation per item.
**Fix**: Batch serialize into single buffer, stream serialization, or use binary format.

## Memory Topology Checks

### Missing First-Touch
**Pattern**: Memory initialized on one NUMA node but used primarily on another.
**Impact**: Cross-socket memory access latency.
**Fix**: First-touch policy, explicit NUMA-aware allocation, or thread pinning.

### Cross-Socket Access
**Pattern**: Data accessed from threads on different NUMA nodes without locality.
**Impact**: Increased memory latency, bandwidth contention.
**Fix**: Partition data by NUMA node, pin threads, or replicate read-only data.

### Lack of Thread Pinning
**Pattern**: High-performance threads migrating across cores.
**Impact**: Cache invalidation, lost locality, variable latency.
**Fix**: Pin threads to specific cores or NUMA nodes with `core_affinity`.

### False Sharing Candidates
**Pattern**: Frequently-modified variables adjacent in memory accessed by different threads.
**Impact**: Cache line bouncing, serialized access despite no logical dependency.
**Fix**: Pad to separate cache lines (64 bytes), or separate hot variables into different allocations.

## Atomic Operation Checks

### SeqCst on Contended Paths
**Pattern**: `Ordering::SeqCst` or `Ordering::AcqRel` where `Relaxed` or `Acquire`/`Release` suffices.
**Impact**: Stronger memory barriers, reduced parallelism.
**Fix**: Use weakest necessary ordering, often `Relaxed` for counters with eventual consistency.

### Wide Atomics
**Pattern**: `AtomicU64` or larger on 32-bit platforms, or in contended scenarios.
**Impact**: May require locks on some platforms, or cause false sharing.
**Fix**: Split into multiple narrow atomics, shard counters, or use platform-appropriate width.

### Shared Counters Without Sharding
**Pattern**: Single global `AtomicUsize` counter updated from many threads.
**Impact**: Cache line contention, serialization point.
**Fix**: Per-thread or per-CPU counters, aggregate lazily.

## Networking and Storage Checks

### Queue Depth of 1
**Pattern**: Synchronous I/O or single outstanding operation to storage/network.
**Impact**: Cannot hide latency, poor throughput on high-latency devices.
**Fix**: Async I/O with multiple in-flight operations, use `io_uring` or libaio.

### Misaligned Writes
**Pattern**: Write offsets or sizes not aligned to block boundaries.
**Impact**: Read-modify-write overhead, increased I/O operations.
**Fix**: Align writes to 4KB or device block size, buffer to alignment.

### Disabled NIC Offloads
**Pattern**: GSO, TSO, or checksum offload disabled or not utilized.
**Impact**: CPU cycles spent on work NIC can do, reduced throughput.
**Fix**: Enable offloads in driver/kernel, use large send buffers.

### Small TLS Records
**Pattern**: Sending many small TLS records instead of batching.
**Impact**: Per-record overhead, poor throughput, CPU waste.
**Fix**: Buffer application data, flush at message boundaries or timer.

## Serialization and Text Checks

### Regex Backtracking
**Pattern**: Complex regex with alternation or nesting on untrusted input.
**Impact**: Exponential worst-case time, DoS risk.
**Fix**: Simplify regex, use anchors, or switch to DFA-based engine.

### Repeated UTF-8 Decode
**Pattern**: Validating or decoding same UTF-8 data multiple times.
**Impact**: Redundant work, memory bandwidth.
**Fix**: Validate once, use trusted slices, or work with bytes directly where safe.

### Base64 Churn
**Pattern**: Encode/decode base64 in hot paths when binary would work.
**Impact**: 33% size overhead, CPU for encode/decode.
**Fix**: Use binary formats internally, base64 only at edges.

### JSON Where Binary Fits
**Pattern**: `serde_json` in high-throughput or low-latency paths.
**Impact**: Parse overhead, larger payloads, allocation.
**Fix**: Use `bincode`, `postcard`, `rmp`, or `capnp` for internal formats.

## Hashing and Map Checks

### DOS-Resistant Hasher on Trusted Input
**Pattern**: `HashMap` default hasher (SipHash) on internal, trusted data in hot paths.
**Impact**: Slower hashing for security not needed here.
**Fix**: Use `FxHashMap` or `AHashMap` for internal data.

### High Collision Rates
**Pattern**: Many entries mapping to same hash bucket.
**Impact**: Linear search in bucket, degraded from O(1) to O(n).
**Fix**: Better hash function, or switch to `BTreeMap` if ordering helps.

### Map Used as LRU Without Eviction
**Pattern**: `HashMap` growing without bound used for caching.
**Impact**: Memory growth, eventual OOM.
**Fix**: Use proper LRU cache with size limit and eviction.

### Sorted Vec Alternative
**Pattern**: `HashMap` or `BTreeMap` with <100 entries and mostly lookups.
**Impact**: Allocation and indirection overhead for small sets.
**Fix**: Use sorted `Vec` with `binary_search`, often faster for small n.

## Build and Codegen Checks

### Missing target-cpu=native
**Pattern**: Building without `-C target-cpu=native` or specific CPU features on known hardware.
**Impact**: Missing SIMD instructions, AVX2, etc.
**Fix**: Add to RUSTFLAGS for deployment target, or use `target-cpu=native` for local builds.

### No LTO or PGO
**Pattern**: Release builds without link-time optimization or profile-guided optimization.
**Impact**: Missed cross-crate inlining, less aggressive optimization.
**Fix**: Add `lto = "thin"` or `"fat"` to Cargo profile, consider PGO for hot services.

### High Codegen Units
**Pattern**: `codegen-units` > 1 in performance-critical builds.
**Impact**: Limits cross-function optimization, smaller optimization scope.
**Fix**: Set `codegen-units = 1` in release profile for maximum performance.

### Panic=Unwind on Latency Paths
**Pattern**: `panic = "unwind"` in latency-sensitive or real-time code.
**Impact**: Larger binary, unwinding overhead, unpredictable timing.
**Fix**: Use `panic = "abort"` where appropriate, handle errors explicitly.

### Missing CPU Features
**Pattern**: Not enabling AVX2, SSE4.2, or other available ISA extensions.
**Impact**: Slower code paths, missed SIMD opportunities.
**Fix**: Check target hardware, enable with `-C target-feature=+avx2` etc.

## Binary and Code Layout Checks

### Excessive Cold Path Inlining
**Pattern**: Large cold error-handling or debug functions inlined into hot paths.
**Impact**: I-cache pollution, larger binaries, slower hot path.
**Fix**: Mark cold functions `#[cold]` and `#[inline(never)]`.

### Monomorphization Explosion
**Pattern**: Generics instantiated many times with slight type variations.
**Impact**: Code bloat, compile time, I-cache pressure.
**Fix**: Use trait objects for cold paths, reduce generic parameter diversity, or manual monomorphization control.

## Logging and Timing Checks

### Synchronous Logging in Hot Paths
**Pattern**: `log`, `env_logger`, or similar blocking in latency-sensitive code.
**Impact**: Log write latency injected into request path.
**Fix**: Async logging, buffered channels, or rate-limited/sampled logging.

### High-Cardinality Labels
**Pattern**: Metrics or logs with many unique label values (user IDs, timestamps).
**Impact**: Memory growth, query slowness, storage bloat.
**Fix**: Limit cardinality, use aggregation, sample high-volume labels.

### Instant::now Per Iteration
**Pattern**: Calling `Instant::now()` or `SystemTime::now()` in tight loops.
**Impact**: VDSO call overhead adds up, possible cache effects.
**Fix**: Sample time less frequently, use TSC-based fast timers, or amortize over iterations.

### Crypto RNG in Tight Loops
**Pattern**: `rand::thread_rng()` or crypto-secure RNG for non-security-sensitive randomness in hot paths.
**Impact**: Slow RNG, syscall overhead.
**Fix**: Use `SmallRng` or `Xoshiro256Plus` for speed where crypto properties not needed.
