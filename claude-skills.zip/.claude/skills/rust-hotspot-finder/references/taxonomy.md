# Performance Hotspot Taxonomy

This taxonomy guides classification of performance issues. Each category represents a distinct performance pattern with specific diagnostic and remediation strategies.

## Core Categories

### Algorithmic Complexity
Issues where the time or space complexity of an algorithm dominates performance. Look for O(n²) or worse, redundant work, or missed caching opportunities.

### Data Layout and Locality
Cache-unfriendly access patterns, AoS vs SoA mismatches, strided access, pointer chasing, and poor spatial locality.

### Allocations and Copies
Excessive heap allocation, unnecessary clones, copy-heavy operations, missing in-place updates, or buffer reuse opportunities.

### Branch Predictability
Hard-to-predict branches in hot paths, data-dependent conditionals, or opportunities for branchless code.

### SIMD Potential and Alignment
Operations that could benefit from vectorization, misaligned data preventing SIMD, or manual unrolling where SIMD applies.

### Synchronization and False Sharing
Lock contention, false sharing on cache lines, unnecessary synchronization, or shared state that could be partitioned.

### I/O and Async Boundaries
Blocking I/O in async contexts, unnecessary context switches, small I/O operations that could be batched, or mismatched buffer sizes.

### Instruction Throughput and ILP
Instruction-level parallelism opportunities, dependency chains, port saturation, or micro-op fusion potential.

### I-cache and Code Layout
Instruction cache misses from poor code layout, excessive inlining, or cold code interleaved with hot code.

### TLB and Page Behavior
TLB misses from excessive virtual memory usage, huge page opportunities, or poor page locality.

### NUMA Locality
Cross-socket memory access, missing first-touch initialization, or thread affinity issues on NUMA systems.

### Memory Ordering and Atomics
Unnecessarily strong memory ordering (SeqCst), atomic operations where relaxed suffices, or wide atomics causing false sharing.

### Lock Convoying and Priority Inversion
Lock holder preemption, convoy effects, or priority inversion in real-time contexts.

### Work Granularity and Batching
Tasks that are too fine-grained for threading overhead, or operations that could be batched for amortization.

### Syscalls and Context Switches
Excessive syscalls, frequent thread context switches, or kernel transitions that could be avoided.

### Storage Queue Depth and Block Alignment
I/O queue depth of 1, misaligned writes to storage, or missed parallelism opportunities in storage operations.

### Networking Stack and NIC Offloads
Disabled hardware offloads (TSO, GSO, checksum), small packet sizes, or missed zero-copy opportunities.

### Serialization and Text Processing
Inefficient serialization formats, repeated parsing, text processing where binary would work, or regex backtracking.

### Compression and Cryptography Usage
Compression in hot paths where throughput matters, cryptographic operations without hardware acceleration.

### Hashing and Map Selection
Poor hash function choice, high collision rates, or wrong data structure (HashMap where FxHashMap fits, sorted Vec as alternative).

### Data Structure Choice
Suboptimal container selection (Vec vs VecDeque, HashMap vs BTreeMap), or custom structures where standard library fits.

### Logging and Tracing Overhead
Synchronous logging in hot paths, high-cardinality labels causing overhead, or enabled debug instrumentation in release builds.

### Time and Randomness in Hot Paths
Frequent time queries (Instant::now), cryptographic RNG where fast RNG suffices, or clock_gettime in tight loops.

### Build and Codegen Configuration
Missing optimization flags, high codegen units preventing optimization, or target-specific features disabled.

### Binary Size and I-cache Pressure
Monomorphization explosion, excessive generic instantiation, or inlining cold paths into hot ones.

### Scheduler and Async Runtime Behavior
Spawn-per-request patterns, blocking in async context, runtime contention, or mismatched executor configuration.

### OS and Platform Limits
Hitting file descriptor limits, small stack sizes, kernel buffer tuning, or resource limits.

### Cold Start and Initialization
Slow startup paths affecting latency, missing lazy initialization, or front-loaded work that could be deferred.
