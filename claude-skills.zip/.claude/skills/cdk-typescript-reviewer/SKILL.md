---
name: cdk-typescript-reviewer
description: Review CDK TypeScript code for idiomatic usage, safety, and maintainability. Use when the user asks to review CDK stacks, audit IAM policies, analyze cdk diff output, suggest construct upgrades, validate networking configuration, add logging/monitoring, enforce naming conventions, or generate improvement patches for CDK TypeScript projects.
---

# CDK TypeScript Reviewer

Review AWS CDK TypeScript code for best practices, security, cost optimization, and maintainability.

## When to Use This Skill

Trigger this skill when the user requests:
- Review CDK stack for best practices
- Audit IAM policies for least privilege
- Explain resource churn in `cdk diff` output
- Suggest L2 constructs instead of L1 (Cfn)
- Add standardized logging, metrics, or alarms
- Validate VPC, subnet, and security group configuration
- Generate patches to improve CDK code
- Enforce naming and tagging conventions
- Optimize CDK stacks for cost
- Review ECS, Lambda, ALB, or other AWS service configurations

## Review Workflow

### 1. Understand the Request

Clarify what the user wants reviewed:
- Entire stack or specific files?
- Focus areas (IAM, networking, cost, logging)?
- Specific concerns or known issues?
- Target AWS services (ECS, Lambda, RDS, etc.)?

### 2. Load Relevant Reference Documentation

Read the appropriate reference files based on the review focus:

**Always read:**
- `references/best-practices.md` - Core CDK best practices
- `references/anti-patterns.md` - Common mistakes to flag

**Read based on focus area:**
- IAM review → `references/iam-patterns.md`
- Networking review → `references/networking-guide.md`
- L1 constructs present → `references/construct-upgrades.md`
- Cost concerns → `references/cost-optimization.md`
- Organization standards → `references/org-conventions.md` (if customized)

### 3. Analyze the Code

Review CDK TypeScript code for:

**Safety Issues (Critical):**
- Overly broad IAM permissions (`actions: ['*']`, `resources: ['*']`)
- Administrative managed policies
- Missing removal policies on stateful resources
- Public access to sensitive resources
- Missing encryption on data stores
- Security groups with `allowAllOutbound: true`
- Hardcoded credentials or secrets

**Best Practice Violations (High):**
- L1 (Cfn) constructs where L2 available
- Manual IAM instead of grant methods
- Missing logging or monitoring
- No health checks on ECS/ALB
- Missing alarms on critical resources
- Wrong subnet types for resources
- Missing tags

**Maintainability Issues (Medium):**
- Hardcoded values (should be constants or props)
- Poor naming conventions
- Missing descriptions on security group rules
- Tightly coupled stacks
- No environment-specific configuration

**Cost Optimization Opportunities (Medium):**
- Over-provisioned resources (Lambda memory, ECS task size)
- NAT Gateways in dev/staging
- Missing S3 lifecycle rules
- No CloudWatch log retention
- Always-on resources in non-prod
- Missing auto-scaling

### 4. Generate Review Output

Provide a structured review with:

**Risk Summary:**
```
Critical: X issues
High: Y issues
Medium: Z issues
```

**Findings by Category:**

For each issue, provide:
1. **Severity**: Critical/High/Medium/Low
2. **Location**: File and line number (if known)
3. **Issue**: What's wrong
4. **Impact**: Why it matters (security, cost, reliability)
5. **Recommendation**: How to fix it
6. **Example**: Code showing the fix (if applicable)

**Example Finding Format:**
```
🔴 CRITICAL: Overly Broad IAM Policy
Location: lib/api-stack.ts (line 45)

Issue:
Lambda function has wildcard permissions on all S3 buckets:
  actions: ['s3:*']
  resources: ['*']

Impact:
Function can read, write, or delete any S3 object in the account, violating least privilege.

Recommendation:
Use the grant method to scope permissions to specific bucket:
  bucket.grantReadWrite(lambda)

Or if manual policy needed, scope to specific actions and resources:
  lambda.addToRolePolicy(new iam.PolicyStatement({
    actions: ['s3:GetObject', 's3:PutObject'],
    resources: [`${bucket.bucketArn}/*`],
  }))
```

### 5. Provide Actionable Fixes

When suggesting fixes:
- Show concrete code examples
- Explain the reasoning
- Indicate if breaking changes are involved
- Provide migration steps for complex changes
- Generate unified diffs when appropriate

**Diff Format Example:**
```diff
- const fn = new lambda.CfnFunction(this, 'Fn', {
-   runtime: 'nodejs18.x',
-   handler: 'index.handler',
-   code: { s3Bucket: 'bucket', s3Key: 'code.zip' },
-   role: role.roleArn,
- });
+ const fn = new lambda.Function(this, 'Fn', {
+   runtime: lambda.Runtime.NODEJS_18_X,
+   handler: 'index.handler',
+   code: lambda.Code.fromAsset('lambda'),
+   logRetention: logs.RetentionDays.ONE_WEEK,
+ });
```

## Special Review Scenarios

### Reviewing `cdk diff` Output

When user provides `cdk diff` output:
1. Identify resource replacements (marked with `[-/+]`)
2. Explain why replacement is happening
3. Assess impact (data loss risk, downtime)
4. Suggest alternatives if replacement is unintended

**Common replacement causes:**
- Changing immutable properties
- Renaming logical IDs
- Changing encryption settings
- Modifying primary keys

### IAM Policy Audit

Focus on:
- Identifying privilege escalation paths
- Flagging destructive actions without conditions
- Finding missing conditions on sensitive operations
- Suggesting grant methods over manual policies
- Checking for proper trust policies on roles

### Networking Validation

Check:
- Correct subnet types for each resource
- Security group rules are explicit (not too open)
- Load balancer health checks configured
- Private resources not in public subnets
- VPC endpoints used instead of NAT where possible
- Cross-AZ configuration for HA

### Cost Review

Identify:
- Over-provisioned Lambda memory/timeout
- Multiple NAT Gateways in non-prod
- Missing S3 lifecycle rules
- No CloudWatch log retention
- RDS instance sizes
- Missing auto-scaling configuration

## Output Formatting

Structure the review for clarity:

```
# CDK Review: [Stack Name]

## Risk Summary
Critical: X | High: Y | Medium: Z | Low: W

## Critical Issues
[List critical findings with details]

## High Priority Issues
[List high priority findings]

## Improvement Opportunities
[List medium/low priority suggestions]

## Recommended Actions
1. [Prioritized list of fixes]
2. [Starting with critical issues]
3. [Then high priority]

## Cost Optimization Opportunities
[List potential cost savings]
```

## Best Practices for Reviews

- **Be specific**: Reference exact line numbers, construct IDs, resource names
- **Explain impact**: Always say why something matters (security, cost, reliability)
- **Provide examples**: Show correct code, not just descriptions
- **Prioritize**: Focus on critical/high issues first
- **Be constructive**: Frame as improvements, not just problems
- **Consider context**: Production vs dev environments have different standards

## Integration with cdk diff

If user mentions resource churn or provides `cdk diff` output:
1. Parse the diff to identify changes
2. Categorize changes: additions, modifications, deletions, replacements
3. Flag any replacements (these cause downtime/data loss)
4. Explain root cause of each replacement
5. Suggest fixes to avoid unintended changes

## Using Organizational Conventions

If `references/org-conventions.md` has been customized with organization-specific standards, validate code against:
- Naming conventions
- Required tags
- Security standards
- Logging standards
- Stack boundaries
- Deployment practices

If not customized, skip org-specific validation and focus on general best practices.

## Tools and Commands

When reviewing:
- Suggest running `cdk synth` to see generated CloudFormation
- Recommend `cdk diff` to preview changes before deployment
- Mention `cdk doctor` for checking CDK/environment issues
- Reference CDK Nag for automated policy checks

## Common Services Review Patterns

### Lambda Functions
- Memory size appropriate
- Timeout not excessive
- Reserved concurrency set
- Dead letter queue configured
- Log retention set
- VPC configuration correct (if applicable)
- Environment variables use references, not hardcoded values

### ECS Services
- Multiple tasks for HA
- Health checks configured
- Circuit breaker enabled
- Logging configured with retention
- Task IAM roles, not instance roles
- Proper subnet selection
- Auto-scaling configured

### RDS Databases
- In isolated subnets
- Not publicly accessible
- Encryption enabled
- Backup retention set
- Deletion protection enabled (prod)
- Multi-AZ enabled (prod)
- Appropriate instance size

### S3 Buckets
- Encryption enabled
- Block public access configured
- Versioning considered
- Lifecycle rules set
- Removal policy explicit

### Security Groups
- Explicit egress rules (not allowAllOutbound)
- Descriptive rule descriptions
- No 0.0.0.0/0 for SSH/RDP
- Scoped to specific source SGs when possible

## Escalation Patterns

For complex issues that need deeper analysis:
- Suggest testing in dev environment first
- Recommend AWS Well-Architected Review
- Point to CDK best practices documentation
- Suggest security review for sensitive changes
- Recommend cost analysis tools for optimization

## Review Checklist

Use this checklist for comprehensive reviews:

- [ ] IAM policies follow least privilege
- [ ] No administrative managed policies
- [ ] Stateful resources have removal policies
- [ ] Data stores encrypted
- [ ] Security groups have explicit rules
- [ ] Resources in appropriate subnets
- [ ] Logging configured with retention
- [ ] Critical resources have alarms
- [ ] Resources properly tagged
- [ ] L2 constructs used instead of L1 where available
- [ ] Grant methods used instead of manual IAM
- [ ] No hardcoded credentials
- [ ] No hardcoded resource names/IDs
- [ ] Environment-specific configuration
- [ ] Health checks on ECS/ALB
- [ ] Cost optimization applied
- [ ] Naming conventions followed
