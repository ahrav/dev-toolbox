# CDK TypeScript Best Practices

## Core Principles

### Use L2 Constructs Over L1 (Cfn)
L2 constructs provide better defaults, type safety, and convenience methods. Only use L1 constructs when L2 equivalents don't exist or when you need specific CloudFormation properties not exposed by L2.

**Prefer:**
```typescript
const bucket = new s3.Bucket(this, 'MyBucket', {
  encryption: s3.BucketEncryption.S3_MANAGED,
  versioned: true,
});
```

**Over:**
```typescript
const bucket = new s3.CfnBucket(this, 'MyBucket', {
  bucketEncryption: {
    serverSideEncryptionConfiguration: [{
      serverSideEncryptionByDefault: {
        sseAlgorithm: 's3',
      },
    }],
  },
  versioningConfiguration: { status: 'Enabled' },
});
```

### Grant Methods Over Manual IAM
Use built-in grant methods instead of manually constructing IAM policies. They follow least privilege by default.

**Prefer:**
```typescript
bucket.grantRead(lambda);
```

**Over:**
```typescript
lambda.addToRolePolicy(new iam.PolicyStatement({
  actions: ['s3:GetObject', 's3:ListBucket'],
  resources: [bucket.bucketArn, `${bucket.bucketArn}/*`],
}));
```

### Removal Policies
Always explicitly set removal policies for stateful resources.

```typescript
const bucket = new s3.Bucket(this, 'DataBucket', {
  removalPolicy: cdk.RemovalPolicy.RETAIN, // Prevent accidental deletion
});

const table = new dynamodb.Table(this, 'Table', {
  removalPolicy: cdk.RemovalPolicy.DESTROY, // OK for dev/test
  // Consider RETAIN or SNAPSHOT for production
});
```

### Use Aspects for Cross-Cutting Concerns
Aspects allow you to apply policies across multiple resources without modifying each construct.

```typescript
import { IAspect, IConstruct, Annotations } from 'aws-cdk-lib';

class BucketEncryptionAspect implements IAspect {
  visit(node: IConstruct): void {
    if (node instanceof s3.Bucket) {
      if (!node.encryption) {
        Annotations.of(node).addError('S3 buckets must have encryption enabled');
      }
    }
  }
}

Aspects.of(stack).add(new BucketEncryptionAspect());
```

## Resource-Specific Best Practices

### Lambda

**Timeout and Memory:**
```typescript
const fn = new lambda.Function(this, 'Fn', {
  timeout: cdk.Duration.seconds(30), // Always set explicit timeout
  memorySize: 1024, // Match to actual needs
  reservedConcurrentExecutions: 10, // Prevent runaway costs
});
```

**Environment Variables:**
```typescript
// Use references instead of hardcoding
const fn = new lambda.Function(this, 'Fn', {
  environment: {
    BUCKET_NAME: bucket.bucketName, // Not bucket ARN!
    TABLE_NAME: table.tableName,
  },
});
```

**Dead Letter Queues:**
```typescript
const dlq = new sqs.Queue(this, 'DLQ', {
  retentionPeriod: cdk.Duration.days(14),
});

const fn = new lambda.Function(this, 'Fn', {
  deadLetterQueue: dlq,
  deadLetterQueueEnabled: true,
});
```

### ECS

**Task Definitions:**
```typescript
const taskDef = new ecs.FargateTaskDefinition(this, 'Task', {
  memoryLimitMiB: 512,
  cpu: 256,
});

const container = taskDef.addContainer('app', {
  image: ecs.ContainerImage.fromRegistry('nginx'),
  logging: ecs.LogDrivers.awsLogs({ 
    streamPrefix: 'app',
    logRetention: logs.RetentionDays.ONE_WEEK, // Always set retention
  }),
  healthCheck: {
    command: ['CMD-SHELL', 'curl -f http://localhost/ || exit 1'],
    interval: cdk.Duration.seconds(30),
    timeout: cdk.Duration.seconds(5),
    retries: 3,
  },
});
```

**Services:**
```typescript
const service = new ecs.FargateService(this, 'Service', {
  cluster,
  taskDefinition: taskDef,
  desiredCount: 2, // Always run multiple tasks for HA
  minHealthyPercent: 50,
  maxHealthyPercent: 200,
  circuitBreaker: { rollback: true }, // Enable deployment circuit breaker
});
```

### ALB/NLB

**Target Groups:**
```typescript
const targetGroup = new elbv2.ApplicationTargetGroup(this, 'TG', {
  vpc,
  port: 80,
  protocol: elbv2.ApplicationProtocol.HTTP,
  healthCheck: {
    path: '/health',
    interval: cdk.Duration.seconds(30),
    timeout: cdk.Duration.seconds(5),
    healthyThresholdCount: 2,
    unhealthyThresholdCount: 3,
  },
  deregistrationDelay: cdk.Duration.seconds(30),
});
```

**Listeners:**
```typescript
const listener = alb.addListener('Listener', {
  port: 443,
  protocol: elbv2.ApplicationProtocol.HTTPS,
  certificates: [certificate],
  defaultAction: elbv2.ListenerAction.fixedResponse(404, {
    contentType: 'text/plain',
    messageBody: 'Not Found',
  }),
});

// Use conditions for routing
listener.addTargets('Target', {
  priority: 10,
  conditions: [
    elbv2.ListenerCondition.pathPatterns(['/api/*']),
  ],
  targetGroups: [targetGroup],
});
```

### CloudWatch

**Alarms:**
```typescript
const alarm = new cloudwatch.Alarm(this, 'ErrorAlarm', {
  metric: fn.metricErrors(),
  threshold: 10,
  evaluationPeriods: 2,
  datapointsToAlarm: 2, // Avoid false positives
  treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
});
```

**Dashboards:**
```typescript
const dashboard = new cloudwatch.Dashboard(this, 'Dashboard', {
  dashboardName: 'app-metrics',
});

dashboard.addWidgets(
  new cloudwatch.GraphWidget({
    left: [fn.metricInvocations(), fn.metricErrors()],
    title: 'Lambda Metrics',
  })
);
```

### VPC and Networking

**VPC Configuration:**
```typescript
const vpc = new ec2.Vpc(this, 'VPC', {
  maxAzs: 2, // Cost optimization for non-prod
  natGateways: 1, // Consider 0 for dev, 2+ for prod HA
  subnetConfiguration: [
    {
      cidrMask: 24,
      name: 'Public',
      subnetType: ec2.SubnetType.PUBLIC,
    },
    {
      cidrMask: 24,
      name: 'Private',
      subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS,
    },
    {
      cidrMask: 28,
      name: 'Isolated',
      subnetType: ec2.SubnetType.PRIVATE_ISOLATED,
    },
  ],
});
```

**Security Groups:**
```typescript
const sg = new ec2.SecurityGroup(this, 'SG', {
  vpc,
  description: 'Allow HTTP traffic', // Always provide description
  allowAllOutbound: false, // Prefer explicit egress rules
});

sg.addIngressRule(
  ec2.Peer.ipv4('10.0.0.0/8'),
  ec2.Port.tcp(80),
  'Allow HTTP from internal networks'
);

sg.addEgressRule(
  ec2.Peer.anyIpv4(),
  ec2.Port.tcp(443),
  'Allow HTTPS to anywhere'
);
```

## Stack Organization

### Single Responsibility
Each stack should have a clear, single purpose. Split large stacks into focused, composable stacks.

```typescript
// Good: Focused stacks
const networkStack = new NetworkStack(app, 'Network');
const databaseStack = new DatabaseStack(app, 'Database', { vpc: networkStack.vpc });
const apiStack = new ApiStack(app, 'Api', { vpc: networkStack.vpc, db: databaseStack.table });
```

### Use Stack Props for Dependencies
Pass dependencies through stack props rather than importing across stacks.

```typescript
interface ApiStackProps extends cdk.StackProps {
  vpc: ec2.IVpc;
  table: dynamodb.ITable;
}

class ApiStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: ApiStackProps) {
    super(scope, id, props);
    // Use props.vpc and props.table
  }
}
```

### Environment Agnostic
Write stacks to work across environments using context or parameters.

```typescript
const env = this.node.tryGetContext('environment') || 'dev';
const isProduction = env === 'prod';

const bucket = new s3.Bucket(this, 'Bucket', {
  removalPolicy: isProduction 
    ? cdk.RemovalPolicy.RETAIN 
    : cdk.RemovalPolicy.DESTROY,
});
```

## Testing

### Unit Tests
Test construct instantiation and property configuration.

```typescript
test('Lambda has DLQ configured', () => {
  const app = new cdk.App();
  const stack = new MyStack(app, 'TestStack');
  const template = Template.fromStack(stack);
  
  template.hasResourceProperties('AWS::Lambda::Function', {
    DeadLetterConfig: {
      TargetArn: Match.anyValue(),
    },
  });
});
```

### Snapshot Tests
Catch unintended changes to generated CloudFormation.

```typescript
test('Stack snapshot', () => {
  const app = new cdk.App();
  const stack = new MyStack(app, 'TestStack');
  const template = Template.fromStack(stack);
  
  expect(template.toJSON()).toMatchSnapshot();
});
```

## Cost Optimization

### Right-Size Resources
```typescript
// Don't over-provision
const fn = new lambda.Function(this, 'Fn', {
  memorySize: 256, // Start small, scale up based on metrics
  timeout: cdk.Duration.seconds(30), // Not Duration.minutes(15)!
});
```

### Use Lifecycle Policies
```typescript
const bucket = new s3.Bucket(this, 'LogBucket', {
  lifecycleRules: [{
    transitions: [{
      storageClass: s3.StorageClass.INFREQUENT_ACCESS,
      transitionAfter: cdk.Duration.days(30),
    }, {
      storageClass: s3.StorageClass.GLACIER,
      transitionAfter: cdk.Duration.days(90),
    }],
    expiration: cdk.Duration.days(365),
  }],
});
```

### Consider Serverless Options
Replace EC2/ECS with Lambda or Fargate Spot when appropriate to reduce costs.
