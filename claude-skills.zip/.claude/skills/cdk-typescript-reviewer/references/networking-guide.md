# Networking Best Practices

## VPC Design Patterns

### Multi-Tier VPC

Standard pattern with public, private, and isolated tiers:

```typescript
const vpc = new ec2.Vpc(this, 'VPC', {
  ipAddresses: ec2.IpAddresses.cidr('10.0.0.0/16'),
  maxAzs: 3, // Use 3 AZs for production HA
  natGateways: 3, // One per AZ for HA
  subnetConfiguration: [
    {
      cidrMask: 24,
      name: 'Public',
      subnetType: ec2.SubnetType.PUBLIC,
    },
    {
      cidrMask: 24,
      name: 'Private',
      subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS,
    },
    {
      cidrMask: 24,
      name: 'Isolated',
      subnetType: ec2.SubnetType.PRIVATE_ISOLATED,
    },
  ],
});
```

### Cost-Optimized Development VPC

```typescript
const vpc = new ec2.Vpc(this, 'DevVPC', {
  maxAzs: 2, // Reduce AZs for cost
  natGateways: 0, // No NAT gateways
  subnetConfiguration: [
    {
      name: 'Public',
      subnetType: ec2.SubnetType.PUBLIC,
    },
    {
      name: 'Isolated',
      subnetType: ec2.SubnetType.PRIVATE_ISOLATED,
    },
  ],
});

// Use VPC endpoints for AWS services instead of NAT
vpc.addGatewayEndpoint('S3Endpoint', {
  service: ec2.GatewayVpcEndpointAwsService.S3,
});

vpc.addInterfaceEndpoint('EcrEndpoint', {
  service: ec2.InterfaceVpcEndpointAwsService.ECR,
});
```

### VPC Endpoint Patterns

**Gateway Endpoints (free):**
```typescript
// S3
vpc.addGatewayEndpoint('S3Endpoint', {
  service: ec2.GatewayVpcEndpointAwsService.S3,
  subnets: [{ subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS }],
});

// DynamoDB
vpc.addGatewayEndpoint('DynamoEndpoint', {
  service: ec2.GatewayVpcEndpointAwsService.DYNAMODB,
});
```

**Interface Endpoints (cost per hour + data):**
```typescript
// ECR
vpc.addInterfaceEndpoint('EcrEndpoint', {
  service: ec2.InterfaceVpcEndpointAwsService.ECR,
  privateDnsEnabled: true, // Enable for ease of use
});

// ECR Docker
vpc.addInterfaceEndpoint('EcrDockerEndpoint', {
  service: ec2.InterfaceVpcEndpointAwsService.ECR_DOCKER,
  privateDnsEnabled: true,
});

// CloudWatch Logs
vpc.addInterfaceEndpoint('LogsEndpoint', {
  service: ec2.InterfaceVpcEndpointAwsService.CLOUDWATCH_LOGS,
  privateDnsEnabled: true,
});

// Secrets Manager
vpc.addInterfaceEndpoint('SecretsEndpoint', {
  service: ec2.InterfaceVpcEndpointAwsService.SECRETS_MANAGER,
  privateDnsEnabled: true,
});
```

## Security Group Patterns

### Tiered Security Groups

**Load Balancer SG:**
```typescript
const albSg = new ec2.SecurityGroup(this, 'AlbSG', {
  vpc,
  description: 'ALB security group',
  allowAllOutbound: false,
});

albSg.addIngressRule(
  ec2.Peer.anyIpv4(),
  ec2.Port.tcp(443),
  'Allow HTTPS from internet'
);

albSg.addEgressRule(
  appSg, // Reference to app SG
  ec2.Port.tcp(8080),
  'Allow traffic to app tier'
);
```

**Application SG:**
```typescript
const appSg = new ec2.SecurityGroup(this, 'AppSG', {
  vpc,
  description: 'Application tier security group',
  allowAllOutbound: false,
});

appSg.addIngressRule(
  albSg,
  ec2.Port.tcp(8080),
  'Allow traffic from ALB'
);

appSg.addEgressRule(
  dbSg,
  ec2.Port.tcp(5432),
  'Allow PostgreSQL to database'
);

appSg.addEgressRule(
  ec2.Peer.anyIpv4(),
  ec2.Port.tcp(443),
  'Allow HTTPS for external APIs'
);
```

**Database SG:**
```typescript
const dbSg = new ec2.SecurityGroup(this, 'DbSG', {
  vpc,
  description: 'Database tier security group',
  allowAllOutbound: false,
});

dbSg.addIngressRule(
  appSg,
  ec2.Port.tcp(5432),
  'Allow PostgreSQL from app tier'
);

// No outbound rules - database doesn't need external access
```

### ECS Service Security Group

```typescript
const ecsServiceSg = new ec2.SecurityGroup(this, 'ServiceSG', {
  vpc,
  description: 'ECS service security group',
  allowAllOutbound: false,
});

// Ingress from ALB
ecsServiceSg.connections.allowFrom(
  alb,
  ec2.Port.tcp(containerPort),
  'Allow traffic from ALB'
);

// Egress to RDS
ecsServiceSg.connections.allowTo(
  database,
  ec2.Port.tcp(5432),
  'Allow PostgreSQL to RDS'
);

// Egress for HTTPS
ecsServiceSg.addEgressRule(
  ec2.Peer.anyIpv4(),
  ec2.Port.tcp(443),
  'Allow HTTPS to AWS services'
);
```

### Lambda Security Group

```typescript
const lambdaSg = new ec2.SecurityGroup(this, 'LambdaSG', {
  vpc,
  description: 'Lambda function security group',
  allowAllOutbound: false,
});

// Lambda to RDS
lambdaSg.connections.allowTo(
  database,
  ec2.Port.tcp(3306),
  'Allow MySQL to RDS'
);

// Lambda to Redis
lambdaSg.connections.allowTo(
  redis,
  ec2.Port.tcp(6379),
  'Allow Redis connection'
);

// HTTPS for AWS SDK calls
lambdaSg.addEgressRule(
  ec2.Peer.anyIpv4(),
  ec2.Port.tcp(443),
  'Allow HTTPS for AWS API calls'
);
```

## Load Balancer Patterns

### Application Load Balancer (ALB)

**HTTPS with redirect:**
```typescript
const alb = new elbv2.ApplicationLoadBalancer(this, 'ALB', {
  vpc,
  internetFacing: true,
  securityGroup: albSg,
  deletionProtection: true, // Prevent accidental deletion in prod
});

// HTTP listener - redirect to HTTPS
alb.addListener('HttpListener', {
  port: 80,
  defaultAction: elbv2.ListenerAction.redirect({
    protocol: 'HTTPS',
    port: '443',
    permanent: true,
  }),
});

// HTTPS listener
const httpsListener = alb.addListener('HttpsListener', {
  port: 443,
  protocol: elbv2.ApplicationProtocol.HTTPS,
  certificates: [certificate],
  sslPolicy: elbv2.SslPolicy.RECOMMENDED, // Use latest TLS
  defaultAction: elbv2.ListenerAction.fixedResponse(404, {
    contentType: 'text/plain',
    messageBody: 'Not Found',
  }),
});
```

**Target Group with health checks:**
```typescript
const targetGroup = new elbv2.ApplicationTargetGroup(this, 'TargetGroup', {
  vpc,
  port: 8080,
  protocol: elbv2.ApplicationProtocol.HTTP,
  targetType: elbv2.TargetType.IP, // For Fargate
  healthCheck: {
    path: '/health',
    interval: cdk.Duration.seconds(30),
    timeout: cdk.Duration.seconds(5),
    healthyThresholdCount: 2,
    unhealthyThresholdCount: 3,
    healthyHttpCodes: '200',
  },
  deregistrationDelay: cdk.Duration.seconds(30), // Reduce for faster deployments
});

// Add routing rule
httpsListener.addTargets('DefaultTarget', {
  priority: 10,
  conditions: [
    elbv2.ListenerCondition.pathPatterns(['/api/*']),
  ],
  targetGroups: [targetGroup],
});
```

**Sticky sessions:**
```typescript
const targetGroup = new elbv2.ApplicationTargetGroup(this, 'TargetGroup', {
  vpc,
  port: 8080,
  stickinessCookieDuration: cdk.Duration.hours(1),
  stickinessCookieName: 'session',
});
```

### Network Load Balancer (NLB)

**TCP load balancer:**
```typescript
const nlb = new elbv2.NetworkLoadBalancer(this, 'NLB', {
  vpc,
  internetFacing: true,
  crossZoneEnabled: true, // Distribute traffic across AZs
  deletionProtection: true,
});

const listener = nlb.addListener('Listener', {
  port: 443,
  protocol: elbv2.Protocol.TCP,
});

const targetGroup = new elbv2.NetworkTargetGroup(this, 'TargetGroup', {
  vpc,
  port: 443,
  protocol: elbv2.Protocol.TCP,
  targetType: elbv2.TargetType.IP,
  healthCheck: {
    protocol: elbv2.Protocol.TCP,
    interval: cdk.Duration.seconds(30),
    healthyThresholdCount: 3,
    unhealthyThresholdCount: 3,
  },
  deregistrationDelay: cdk.Duration.seconds(30),
});

listener.addTargetGroups('DefaultTarget', targetGroup);
```

**TLS termination at NLB:**
```typescript
const listener = nlb.addListener('TlsListener', {
  port: 443,
  protocol: elbv2.Protocol.TLS,
  certificates: [certificate],
  sslPolicy: elbv2.SslPolicy.RECOMMENDED,
});
```

## ECS Networking Patterns

### Fargate Service with ALB

```typescript
const service = new ecs.FargateService(this, 'Service', {
  cluster,
  taskDefinition,
  desiredCount: 2,
  assignPublicIp: false, // Private subnets
  vpcSubnets: {
    subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS,
  },
  securityGroups: [ecsServiceSg],
  healthCheckGracePeriod: cdk.Duration.seconds(60),
  circuitBreaker: { rollback: true },
});

// Attach to ALB target group
service.attachToApplicationTargetGroup(targetGroup);
```

### Service Connect

```typescript
const namespace = new servicediscovery.PrivateDnsNamespace(this, 'Namespace', {
  vpc,
  name: 'local',
});

const service = new ecs.FargateService(this, 'Service', {
  cluster,
  taskDefinition,
  serviceConnectConfiguration: {
    namespace: namespace.namespaceName,
    services: [{
      portMappingName: 'http',
      dnsName: 'api',
      port: 8080,
    }],
  },
});
```

### Service Discovery

```typescript
const namespace = new servicediscovery.PrivateDnsNamespace(this, 'Namespace', {
  vpc,
  name: 'internal.example.com',
});

const service = new ecs.FargateService(this, 'Service', {
  cluster,
  taskDefinition,
  cloudMapOptions: {
    name: 'api',
    cloudMapNamespace: namespace,
    dnsRecordType: servicediscovery.DnsRecordType.A,
    dnsTtl: cdk.Duration.seconds(10),
  },
});

// Service accessible at: api.internal.example.com
```

## Lambda VPC Configuration

### Private Subnet Deployment

```typescript
const fn = new lambda.Function(this, 'Fn', {
  vpc,
  vpcSubnets: {
    subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS,
  },
  securityGroups: [lambdaSg],
  allowPublicSubnet: false, // Prevent deployment to public subnets
});
```

### Accessing VPC Resources

```typescript
// Lambda accessing RDS
const fn = new lambda.Function(this, 'Fn', {
  vpc,
  vpcSubnets: {
    subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS,
  },
  environment: {
    DB_HOST: database.dbInstanceEndpointAddress,
    DB_PORT: database.dbInstanceEndpointPort,
  },
});

// Allow Lambda to connect to RDS
database.connections.allowFrom(fn, ec2.Port.tcp(5432));
```

## Common Networking Issues

### Public Resources in Private Subnets

**❌ Issue: Resource needs internet but in wrong subnet**
```typescript
const service = new ecs.FargateService(this, 'Service', {
  vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_ISOLATED },
  // Can't pull images from ECR!
});
```

**✅ Solution: Use correct subnet type**
```typescript
const service = new ecs.FargateService(this, 'Service', {
  vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
  // Or add VPC endpoints
});
```

### Security Group Circular Dependencies

**❌ Issue: Two SGs referencing each other**
```typescript
const sg1 = new ec2.SecurityGroup(this, 'SG1', { vpc });
const sg2 = new ec2.SecurityGroup(this, 'SG2', { vpc });

sg1.addIngressRule(sg2, ec2.Port.tcp(80));
sg2.addIngressRule(sg1, ec2.Port.tcp(80)); // Circular!
```

**✅ Solution: Use connections or separate rules**
```typescript
sg1.connections.allowFrom(sg2, ec2.Port.tcp(80));
sg2.connections.allowFrom(sg1, ec2.Port.tcp(80));
```

### Missing Egress Rules

**❌ Issue: No outbound connectivity**
```typescript
const sg = new ec2.SecurityGroup(this, 'SG', {
  vpc,
  allowAllOutbound: false,
  // No egress rules added!
});
```

**✅ Solution: Add explicit egress rules**
```typescript
const sg = new ec2.SecurityGroup(this, 'SG', {
  vpc,
  allowAllOutbound: false,
});

sg.addEgressRule(ec2.Peer.anyIpv4(), ec2.Port.tcp(443), 'HTTPS');
```

### Lambda Cold Start Issues

**❌ Issue: ENI creation delays**
Lambda functions in VPC create ENIs which can slow cold starts.

**✅ Mitigation: Use provisioned concurrency**
```typescript
const version = fn.currentVersion;
const alias = new lambda.Alias(this, 'ProdAlias', {
  aliasName: 'prod',
  version,
  provisionedConcurrentExecutions: 5,
});
```

## Subnet Selection Patterns

### ECS Tasks
- **Public subnets**: Only if assignPublicIp = true and needs direct internet
- **Private with egress**: Most common for production
- **Isolated**: Only if no external connectivity needed

### Lambda Functions
- **Private with egress**: Access VPC resources and internet via NAT
- **Isolated**: Access VPC resources only (use VPC endpoints for AWS services)

### RDS Databases
- **Isolated**: Always use isolated subnets for databases

### Load Balancers
- **Public subnets**: For internet-facing ALB/NLB
- **Private subnets**: For internal-only load balancers

## NAT Gateway Cost Optimization

### Environment-Based NAT Configuration

```typescript
const environmentConfig = {
  prod: { natGateways: 3, maxAzs: 3 },
  staging: { natGateways: 1, maxAzs: 2 },
  dev: { natGateways: 0, maxAzs: 2 }, // Use VPC endpoints
};

const env = this.node.tryGetContext('environment') || 'dev';
const config = environmentConfig[env];

const vpc = new ec2.Vpc(this, 'VPC', {
  ...config,
  subnetConfiguration: config.natGateways === 0 
    ? [
        { name: 'Public', subnetType: ec2.SubnetType.PUBLIC },
        { name: 'Isolated', subnetType: ec2.SubnetType.PRIVATE_ISOLATED },
      ]
    : [
        { name: 'Public', subnetType: ec2.SubnetType.PUBLIC },
        { name: 'Private', subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
        { name: 'Isolated', subnetType: ec2.SubnetType.PRIVATE_ISOLATED },
      ],
});
```

### VPC Endpoint Alternative

Replace NAT Gateway with VPC endpoints for AWS service access:

```typescript
// Add endpoints for common services
vpc.addGatewayEndpoint('S3', {
  service: ec2.GatewayVpcEndpointAwsService.S3,
});

vpc.addInterfaceEndpoint('ECR', {
  service: ec2.InterfaceVpcEndpointAwsService.ECR,
});

vpc.addInterfaceEndpoint('ECRDocker', {
  service: ec2.InterfaceVpcEndpointAwsService.ECR_DOCKER,
});

vpc.addInterfaceEndpoint('Logs', {
  service: ec2.InterfaceVpcEndpointAwsService.CLOUDWATCH_LOGS,
});
```
