# IAM Policy Patterns and Common Issues

## Least Privilege Patterns

### S3 Access Patterns

**Read-only access to specific prefix:**
```typescript
new iam.PolicyStatement({
  actions: ['s3:GetObject', 's3:ListBucket'],
  resources: [
    bucket.bucketArn,
    `${bucket.bucketArn}/user-data/*`,
  ],
  conditions: {
    'StringLike': {
      's3:prefix': ['user-data/*'],
    },
  },
});
```

**Write-only access (no read):**
```typescript
new iam.PolicyStatement({
  actions: ['s3:PutObject'],
  resources: [`${bucket.bucketArn}/uploads/*`],
});
```

**Prevent object deletion:**
```typescript
new iam.PolicyStatement({
  effect: iam.Effect.DENY,
  actions: ['s3:DeleteObject', 's3:DeleteObjectVersion'],
  resources: [`${bucket.bucketArn}/*`],
});
```

### DynamoDB Access Patterns

**Read-only access:**
```typescript
table.grant(role, 'dynamodb:GetItem', 'dynamodb:Query', 'dynamodb:Scan');
```

**Write without delete:**
```typescript
table.grant(role, 'dynamodb:PutItem', 'dynamodb:UpdateItem');
```

**Attribute-level access control:**
```typescript
new iam.PolicyStatement({
  actions: ['dynamodb:GetItem'],
  resources: [table.tableArn],
  conditions: {
    'ForAllValues:StringEquals': {
      'dynamodb:Attributes': ['userId', 'timestamp', 'data'],
    },
  },
});
```

### Lambda Invocation Patterns

**Synchronous invocation only:**
```typescript
new iam.PolicyStatement({
  actions: ['lambda:InvokeFunction'],
  resources: [fn.functionArn],
});
```

**Async invocation only:**
```typescript
new iam.PolicyStatement({
  actions: ['lambda:InvokeAsync'],
  resources: [fn.functionArn],
});
```

### Secrets Manager Patterns

**Read-only access to specific secrets:**
```typescript
new iam.PolicyStatement({
  actions: ['secretsmanager:GetSecretValue'],
  resources: [secret.secretArn],
  conditions: {
    'StringEquals': {
      'secretsmanager:VersionStage': 'AWSCURRENT',
    },
  },
});
```

## Common Overly-Broad Patterns to Flag

### Wildcard Actions

**🚨 Flag: Any `*` in actions**
```typescript
// BAD
actions: ['s3:*']
actions: ['dynamodb:*']
actions: ['lambda:*']
actions: ['*']
```

**Severity: High** - Replace with specific actions needed.

### Wildcard Resources

**🚨 Flag: `resources: ['*']`**
```typescript
// BAD
new iam.PolicyStatement({
  actions: ['s3:GetObject'],
  resources: ['*'],
});
```

**Severity: High** - Scope to specific resources.

### Administrative Policies

**🚨 Flag: Administrative managed policies**
```typescript
// BAD
iam.ManagedPolicy.fromAwsManagedPolicyName('AdministratorAccess')
iam.ManagedPolicy.fromAwsManagedPolicyName('PowerUserAccess')
iam.ManagedPolicy.fromAwsManagedPolicyName('IAMFullAccess')
iam.ManagedPolicy.fromAwsManagedPolicyName('AmazonEC2FullAccess')
```

**Severity: Critical** - Use least privilege alternatives.

### Cross-Account Access Without Conditions

**🚨 Flag: Missing ExternalId or conditions**
```typescript
// BAD
new iam.Role(this, 'CrossAccountRole', {
  assumedBy: new iam.AccountPrincipal('123456789012'),
  // No externalId or other conditions!
});
```

**Severity: High** - Add ExternalId or MFA conditions.

### Broad Principal Definitions

**🚨 Flag: AnyPrincipal without conditions**
```typescript
// BAD
principals: [new iam.AnyPrincipal()]
// Without restrictive conditions
```

**Severity: Critical** - Restrict with conditions or use specific principals.

## Dangerous Action Patterns

### Privilege Escalation Actions

**🚨 Flag these actions (often lead to privilege escalation):**
```typescript
// High risk actions
'iam:CreateAccessKey'
'iam:CreateUser'
'iam:AttachUserPolicy'
'iam:AttachRolePolicy'
'iam:PutUserPolicy'
'iam:PutRolePolicy'
'iam:CreatePolicyVersion'
'iam:SetDefaultPolicyVersion'
'iam:PassRole' // Without proper conditions
```

**Severity: Critical** - Require strong justification and conditions.

### Data Destruction Actions

**🚨 Flag these actions (can cause data loss):**
```typescript
// Destructive actions
's3:DeleteBucket'
's3:DeleteObject'
'dynamodb:DeleteTable'
'rds:DeleteDBInstance'
'lambda:DeleteFunction'
```

**Severity: High** - Should have MFA or restrictive conditions.

### Logging and Monitoring Bypass

**🚨 Flag these actions (can hide malicious activity):**
```typescript
// Security bypass actions
'cloudtrail:StopLogging'
'cloudtrail:DeleteTrail'
'logs:DeleteLogGroup'
'cloudwatch:DeleteAlarms'
'guardduty:DeleteDetector'
```

**Severity: Critical** - Should be highly restricted.

## Condition Key Patterns

### IP-Based Restrictions

```typescript
new iam.PolicyStatement({
  actions: ['s3:*'],
  resources: ['*'],
  conditions: {
    'IpAddress': {
      'aws:SourceIp': ['10.0.0.0/8', '192.168.0.0/16'],
    },
  },
});
```

### MFA Requirements

```typescript
new iam.PolicyStatement({
  actions: ['s3:DeleteObject'],
  resources: [`${bucket.bucketArn}/*`],
  conditions: {
    'Bool': {
      'aws:MultiFactorAuthPresent': 'true',
    },
  },
});
```

### Time-Based Access

```typescript
new iam.PolicyStatement({
  actions: ['ec2:*'],
  resources: ['*'],
  conditions: {
    'DateGreaterThan': {
      'aws:CurrentTime': '2024-01-01T00:00:00Z',
    },
    'DateLessThan': {
      'aws:CurrentTime': '2024-12-31T23:59:59Z',
    },
  },
});
```

### Organization Restrictions

```typescript
new iam.PolicyStatement({
  actions: ['s3:GetObject'],
  principals: [new iam.AnyPrincipal()],
  resources: [`${bucket.bucketArn}/*`],
  conditions: {
    'StringEquals': {
      'aws:PrincipalOrgID': 'o-xxxxx',
    },
  },
});
```

### Tag-Based Access Control

```typescript
new iam.PolicyStatement({
  actions: ['ec2:StartInstances', 'ec2:StopInstances'],
  resources: ['*'],
  conditions: {
    'StringEquals': {
      'ec2:ResourceTag/Environment': 'Development',
    },
  },
});
```

## Resource-Based Policy Patterns

### S3 Bucket Policies

**CloudFront OAI access:**
```typescript
bucket.addToResourcePolicy(new iam.PolicyStatement({
  actions: ['s3:GetObject'],
  principals: [new iam.CanonicalUserPrincipal(cloudfrontOai.cloudFrontOriginAccessIdentityS3CanonicalUserId)],
  resources: [`${bucket.bucketArn}/*`],
}));
```

**Cross-account access:**
```typescript
bucket.addToResourcePolicy(new iam.PolicyStatement({
  actions: ['s3:GetObject'],
  principals: [new iam.AccountPrincipal('123456789012')],
  resources: [`${bucket.bucketArn}/shared/*`],
  conditions: {
    'StringEquals': {
      'aws:PrincipalOrgID': 'o-xxxxx',
    },
  },
}));
```

### KMS Key Policies

**Allow service to use key:**
```typescript
key.addToResourcePolicy(new iam.PolicyStatement({
  actions: ['kms:Decrypt', 'kms:GenerateDataKey'],
  principals: [new iam.ServicePrincipal('logs.amazonaws.com')],
  resources: ['*'],
  conditions: {
    'ArnLike': {
      'kms:EncryptionContext:aws:logs:arn': `arn:aws:logs:${region}:${account}:*`,
    },
  },
}));
```

### Lambda Resource Policies

**API Gateway invocation:**
```typescript
fn.addPermission('ApiGatewayInvoke', {
  principal: new iam.ServicePrincipal('apigateway.amazonaws.com'),
  sourceArn: api.arnForExecuteApi(),
});
```

**S3 trigger:**
```typescript
fn.addPermission('S3Invoke', {
  principal: new iam.ServicePrincipal('s3.amazonaws.com'),
  sourceArn: bucket.bucketArn,
  sourceAccount: cdk.Stack.of(this).account,
});
```

## Grant Methods vs Manual Policies

### When to Use Grant Methods

Grant methods are preferred for common access patterns:

```typescript
// ✅ Preferred
bucket.grantRead(lambda);
bucket.grantReadWrite(role);
bucket.grantPut(codebuild);
table.grantReadData(lambda);
table.grantWriteData(stepFunction);
queue.grantSendMessages(lambda);
topic.grantPublish(lambda);
secret.grantRead(ecs);
```

**Benefits:**
- Automatically handles resource ARNs correctly
- Includes necessary actions (e.g., ListBucket + GetObject for S3)
- Less error-prone than manual policies
- Better readability

### When Manual Policies Are Needed

Use manual policies when:

1. Grant methods don't exist for the use case
2. Need custom conditions
3. Require specific action subsets
4. Implementing deny policies
5. Complex cross-service permissions

## Role Trust Policies

### Service Principals

```typescript
const role = new iam.Role(this, 'Role', {
  assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
});
```

### Federated Principals

```typescript
const role = new iam.Role(this, 'Role', {
  assumedBy: new iam.FederatedPrincipal(
    'arn:aws:iam::123456789012:saml-provider/ExampleOrgSSO',
    {
      'StringEquals': {
        'SAML:aud': 'https://signin.aws.amazon.com/saml',
      },
    },
    'sts:AssumeRoleWithSAML'
  ),
});
```

### Cross-Account with ExternalId

```typescript
const role = new iam.Role(this, 'CrossAccountRole', {
  assumedBy: new iam.AccountPrincipal('123456789012'),
  externalIds: ['unique-external-id-12345'],
});
```

## Common Mistakes Summary

**Top 10 IAM Issues to Flag:**

1. ❌ `actions: ['*']` or `resources: ['*']` without strong justification
2. ❌ Using administrative managed policies
3. ❌ `AnyPrincipal()` without restrictive conditions
4. ❌ Missing `externalId` for cross-account roles
5. ❌ Privilege escalation actions without conditions
6. ❌ Data deletion actions without MFA conditions
7. ❌ Not using grant methods when available
8. ❌ Security/logging bypass actions
9. ❌ Hardcoded account IDs or ARNs
10. ❌ Missing or weak trust policy conditions
