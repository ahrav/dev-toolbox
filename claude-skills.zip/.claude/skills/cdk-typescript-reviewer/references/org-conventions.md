# Organizational Conventions

This file contains organization-specific conventions for CDK projects. Customize these patterns to match your organization's standards.

## Naming Conventions

### Resource Naming Pattern

```
{environment}-{application}-{resource-type}-{purpose}
```

**Examples:**
- `prod-api-lambda-handler`
- `dev-webapp-bucket-assets`
- `staging-worker-queue-tasks`

### Stack Naming

```typescript
// Pattern: {AppName}-{Component}-{Environment}
new NetworkStack(app, 'MyApp-Network-Production');
new DatabaseStack(app, 'MyApp-Database-Production');
new ApiStack(app, 'MyApp-Api-Production');
```

### Logical ID Conventions

Use PascalCase for construct IDs:
```typescript
new s3.Bucket(this, 'DataBucket'); // ✅
new s3.Bucket(this, 'data-bucket'); // ❌
```

## Tagging Standards

### Required Tags

Every stack must have:
```typescript
cdk.Tags.of(stack).add('Environment', environment); // prod, staging, dev
cdk.Tags.of(stack).add('Owner', teamName); // Team responsible
cdk.Tags.of(stack).add('CostCenter', costCenter); // For billing
cdk.Tags.of(stack).add('Application', appName); // Application name
```

### Optional Tags

```typescript
cdk.Tags.of(stack).add('Project', projectName);
cdk.Tags.of(stack).add('Compliance', 'pci-dss'); // If applicable
cdk.Tags.of(stack).add('DataClassification', 'confidential');
```

## Security Standards

### IAM Policies

- **Never use** `AdministratorAccess` or `PowerUserAccess` managed policies
- **Always use** grant methods (`bucket.grantRead()`) when available
- **Always add** conditions to sensitive actions
- **Always require** MFA for destructive actions in production

### Encryption

All data must be encrypted at rest:
```typescript
// ✅ S3
new s3.Bucket(this, 'Bucket', {
  encryption: s3.BucketEncryption.S3_MANAGED, // Minimum
  // Or use KMS for sensitive data:
  // encryption: s3.BucketEncryption.KMS,
  // encryptionKey: key,
});

// ✅ DynamoDB
new dynamodb.Table(this, 'Table', {
  encryption: dynamodb.TableEncryption.AWS_MANAGED,
});

// ✅ RDS
new rds.DatabaseInstance(this, 'DB', {
  storageEncrypted: true,
});
```

### Network Isolation

- **Databases**: Always in PRIVATE_ISOLATED subnets
- **Application tier**: PRIVATE_WITH_EGRESS subnets
- **Load balancers**: PUBLIC subnets (only when internet-facing)
- **Never** set `publiclyAccessible: true` for databases

## Logging and Monitoring Standards

### CloudWatch Logs Retention

```typescript
// Required retention periods by environment
const retentionDays = {
  prod: logs.RetentionDays.ONE_MONTH,
  staging: logs.RetentionDays.ONE_WEEK,
  dev: logs.RetentionDays.THREE_DAYS,
};
```

### Required Alarms

All production Lambda functions must have:
```typescript
new cloudwatch.Alarm(this, 'ErrorAlarm', {
  metric: fn.metricErrors(),
  threshold: 5,
  evaluationPeriods: 2,
  treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
});

new cloudwatch.Alarm(this, 'ThrottleAlarm', {
  metric: fn.metricThrottles(),
  threshold: 1,
  evaluationPeriods: 1,
});
```

All production ECS services must have:
```typescript
new cloudwatch.Alarm(this, 'UnhealthyHostAlarm', {
  metric: targetGroup.metricUnhealthyHostCount(),
  threshold: 1,
  evaluationPeriods: 2,
});
```

### Log Formats

Use structured JSON logging:
```typescript
// Lambda environment variable
environment: {
  LOG_LEVEL: 'INFO',
  LOG_FORMAT: 'json',
}
```

## Environment Configuration

### Environment-Specific Settings

```typescript
interface EnvironmentConfig {
  // Resource sizing
  lambdaMemory: number;
  fargateTaskCount: number;
  rdsInstanceType: ec2.InstanceType;
  
  // Cost optimization
  natGateways: number;
  maxAzs: number;
  
  // Security
  deletionProtection: boolean;
  backupRetention: cdk.Duration;
  
  // Monitoring
  logRetention: logs.RetentionDays;
  enableXRay: boolean;
}

const configs: Record<string, EnvironmentConfig> = {
  prod: {
    lambdaMemory: 1024,
    fargateTaskCount: 3,
    rdsInstanceType: ec2.InstanceType.of(ec2.InstanceClass.R6G, ec2.InstanceSize.LARGE),
    natGateways: 2,
    maxAzs: 3,
    deletionProtection: true,
    backupRetention: cdk.Duration.days(30),
    logRetention: logs.RetentionDays.ONE_MONTH,
    enableXRay: true,
  },
  staging: {
    lambdaMemory: 512,
    fargateTaskCount: 2,
    rdsInstanceType: ec2.InstanceType.of(ec2.InstanceClass.T4G, ec2.InstanceSize.MEDIUM),
    natGateways: 1,
    maxAzs: 2,
    deletionProtection: false,
    backupRetention: cdk.Duration.days(7),
    logRetention: logs.RetentionDays.ONE_WEEK,
    enableXRay: false,
  },
  dev: {
    lambdaMemory: 256,
    fargateTaskCount: 1,
    rdsInstanceType: ec2.InstanceType.of(ec2.InstanceClass.T4G, ec2.InstanceSize.SMALL),
    natGateways: 0,
    maxAzs: 2,
    deletionProtection: false,
    backupRetention: cdk.Duration.days(1),
    logRetention: logs.RetentionDays.THREE_DAYS,
    enableXRay: false,
  },
};
```

## Stack Boundaries

### Recommended Stack Organization

1. **Network Stack**: VPC, subnets, NAT gateways, VPC endpoints
2. **Security Stack**: KMS keys, Security Groups (shared)
3. **Database Stack**: RDS, DynamoDB tables
4. **Storage Stack**: S3 buckets, EFS
5. **Compute Stack**: ECS clusters, Lambda functions
6. **API Stack**: API Gateway, ALB/NLB
7. **Monitoring Stack**: CloudWatch dashboards, alarms, SNS topics

### Stack Dependencies

Pass resources through props, never use cross-stack references:
```typescript
// ✅ Good
const apiStack = new ApiStack(app, 'Api', {
  vpc: networkStack.vpc,
  database: databaseStack.table,
});

// ❌ Bad - tight coupling
const apiStack = new ApiStack(app, 'Api');
// Then importing from other stacks inside ApiStack
```

## Deployment Standards

### Required Deployment Steps

1. Run `cdk synth` and review CloudFormation template
2. Run `cdk diff` and review changes
3. Check for resource replacement warnings
4. Verify no hardcoded values or secrets
5. Deploy to dev/staging first
6. Monitor for errors before prod deployment

### Deployment Protections

Production stacks must have:
```typescript
const stack = new cdk.Stack(app, 'ProdStack', {
  terminationProtection: true, // Prevent accidental deletion
});
```

## Code Quality Standards

### Type Safety

- Always enable strict TypeScript: `"strict": true`
- No `any` types without justification
- Use CDK type-safe enums instead of strings

### Testing Requirements

- Unit tests for construct creation
- Snapshot tests to catch unintended changes
- Integration tests for critical paths (production only)

### Code Review Checklist

- [ ] No hardcoded credentials or secrets
- [ ] IAM policies follow least privilege
- [ ] Removal policies set for stateful resources
- [ ] All resources properly tagged
- [ ] Logging configured with appropriate retention
- [ ] Cost optimization applied per environment
- [ ] Security groups have explicit rules (no allowAllOutbound)
- [ ] Naming conventions followed
- [ ] No L1 constructs without justification

## Secrets Management

### Never Commit Secrets

- Use AWS Secrets Manager for credentials
- Use SSM Parameter Store for configuration
- Use context values for non-sensitive config

```typescript
// ✅ Good
const dbPassword = secretsmanager.Secret.fromSecretNameV2(
  this,
  'DBPassword',
  'prod/db/password'
);

// ❌ Bad
const dbPassword = 'hardcoded-password';
```

## Documentation Requirements

### Stack Documentation

Each stack must include:
- Purpose and responsibilities
- Dependencies on other stacks
- Environment-specific considerations
- Deployment instructions

### Inline Comments

Add comments for:
- Non-obvious design decisions
- Workarounds or temporary solutions
- Complex IAM policies
- Cost optimization choices

## Cost Management

### Budget Alerts

Each environment must have budget alerts configured:
```typescript
// Alert at 50%, 80%, 100% of monthly budget
const monthlyBudget = {
  prod: 10000,
  staging: 2000,
  dev: 500,
};
```

### Resource Cleanup

- Automated cleanup of old snapshots (>30 days)
- Automated cleanup of unused EBS volumes
- Regular review of unused resources

## Compliance Requirements

### Data Residency

- All resources must be deployed in approved regions
- Customer data must not leave approved regions

### Audit Logging

- CloudTrail enabled for all accounts
- S3 access logs enabled for all buckets
- VPC Flow Logs enabled

### Backup Requirements

Production databases must have:
- Automated backups enabled
- 30-day retention period
- Cross-region backup replication
