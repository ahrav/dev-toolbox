# CDK TypeScript Anti-Patterns

## IAM Anti-Patterns

### Overly Broad Permissions

**❌ Bad: Wildcard actions**
```typescript
lambda.addToRolePolicy(new iam.PolicyStatement({
  actions: ['s3:*'],
  resources: ['*'],
}));
```

**✅ Good: Specific actions and resources**
```typescript
bucket.grantRead(lambda);
// Or if manual policy needed:
lambda.addToRolePolicy(new iam.PolicyStatement({
  actions: ['s3:GetObject', 's3:ListBucket'],
  resources: [bucket.bucketArn, `${bucket.bucketArn}/*`],
}));
```

### Administrative Access

**❌ Bad: Admin policies**
```typescript
role.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName('AdministratorAccess'));
role.addManagedPolicy(iam.ManagedPolicy.fromAwsManagedPolicyName('PowerUserAccess'));
```

**✅ Good: Least privilege**
```typescript
bucket.grantReadWrite(role);
table.grantReadWriteData(role);
```

### Missing Conditions

**❌ Bad: No conditions on sensitive operations**
```typescript
new iam.PolicyStatement({
  actions: ['s3:DeleteBucket'],
  resources: ['*'],
});
```

**✅ Good: Add protective conditions**
```typescript
new iam.PolicyStatement({
  actions: ['s3:DeleteBucket'],
  resources: [bucket.bucketArn],
  conditions: {
    'StringEquals': {
      'aws:RequestedRegion': 'us-east-1',
    },
  },
});
```

### Resource-Based Policies Without Conditions

**❌ Bad: Open access**
```typescript
bucket.addToResourcePolicy(new iam.PolicyStatement({
  actions: ['s3:GetObject'],
  principals: [new iam.AnyPrincipal()],
  resources: [`${bucket.bucketArn}/*`],
}));
```

**✅ Good: Restrict with conditions**
```typescript
bucket.addToResourcePolicy(new iam.PolicyStatement({
  actions: ['s3:GetObject'],
  principals: [new iam.AnyPrincipal()],
  resources: [`${bucket.bucketArn}/*`],
  conditions: {
    'StringEquals': {
      'aws:PrincipalOrgID': 'o-xxxxx',
    },
  },
}));
```

## Networking Anti-Patterns

### Public Subnets for Private Resources

**❌ Bad: Database in public subnet**
```typescript
const database = new rds.DatabaseInstance(this, 'Database', {
  vpc,
  vpcSubnets: { subnetType: ec2.SubnetType.PUBLIC },
  publiclyAccessible: true,
});
```

**✅ Good: Database in isolated subnet**
```typescript
const database = new rds.DatabaseInstance(this, 'Database', {
  vpc,
  vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_ISOLATED },
  publiclyAccessible: false,
});
```

### Allow All Outbound Traffic

**❌ Bad: Default allow all outbound**
```typescript
const sg = new ec2.SecurityGroup(this, 'SG', {
  vpc,
  allowAllOutbound: true, // Default, but too permissive
});
```

**✅ Good: Explicit egress rules**
```typescript
const sg = new ec2.SecurityGroup(this, 'SG', {
  vpc,
  allowAllOutbound: false,
});

sg.addEgressRule(ec2.Peer.anyIpv4(), ec2.Port.tcp(443), 'HTTPS');
sg.addEgressRule(ec2.Peer.anyIpv4(), ec2.Port.tcp(80), 'HTTP');
```

### Missing Security Group Descriptions

**❌ Bad: No description**
```typescript
sg.addIngressRule(ec2.Peer.anyIpv4(), ec2.Port.tcp(22));
```

**✅ Good: Descriptive rules**
```typescript
sg.addIngressRule(
  ec2.Peer.ipv4('10.0.0.0/8'),
  ec2.Port.tcp(22),
  'SSH access from corporate network'
);
```

### Hardcoded IPs

**❌ Bad: Hardcoded IP addresses**
```typescript
sg.addIngressRule(ec2.Peer.ipv4('1.2.3.4/32'), ec2.Port.tcp(443));
```

**✅ Good: Use references or parameters**
```typescript
const allowedCidr = cdk.Fn.ref('AllowedCIDR'); // From parameter
sg.addIngressRule(ec2.Peer.ipv4(allowedCidr), ec2.Port.tcp(443));
```

## Logging and Monitoring Anti-Patterns

### Missing CloudWatch Logs

**❌ Bad: No logging**
```typescript
const fn = new lambda.Function(this, 'Fn', {
  runtime: lambda.Runtime.NODEJS_18_X,
  handler: 'index.handler',
  code: lambda.Code.fromAsset('lambda'),
});
```

**✅ Good: Explicit log retention**
```typescript
const fn = new lambda.Function(this, 'Fn', {
  runtime: lambda.Runtime.NODEJS_18_X,
  handler: 'index.handler',
  code: lambda.Code.fromAsset('lambda'),
  logRetention: logs.RetentionDays.ONE_WEEK,
});
```

### No Alarms on Critical Metrics

**❌ Bad: No monitoring**
```typescript
const fn = new lambda.Function(this, 'Fn', { /* ... */ });
// No alarms!
```

**✅ Good: Alarm on errors**
```typescript
const fn = new lambda.Function(this, 'Fn', { /* ... */ });

new cloudwatch.Alarm(this, 'ErrorAlarm', {
  metric: fn.metricErrors(),
  threshold: 5,
  evaluationPeriods: 1,
});
```

### Missing ECS Container Logging

**❌ Bad: No logging configuration**
```typescript
taskDef.addContainer('app', {
  image: ecs.ContainerImage.fromRegistry('nginx'),
  // No logging!
});
```

**✅ Good: CloudWatch logging with retention**
```typescript
taskDef.addContainer('app', {
  image: ecs.ContainerImage.fromRegistry('nginx'),
  logging: ecs.LogDrivers.awsLogs({
    streamPrefix: 'app',
    logRetention: logs.RetentionDays.ONE_WEEK,
  }),
});
```

## Resource Management Anti-Patterns

### No Removal Policy

**❌ Bad: Undefined removal behavior**
```typescript
const bucket = new s3.Bucket(this, 'DataBucket', {
  // No removalPolicy specified
});
```

**✅ Good: Explicit removal policy**
```typescript
const bucket = new s3.Bucket(this, 'DataBucket', {
  removalPolicy: cdk.RemovalPolicy.RETAIN, // For production data
});

const logBucket = new s3.Bucket(this, 'LogBucket', {
  removalPolicy: cdk.RemovalPolicy.DESTROY, // OK for logs
  autoDeleteObjects: true, // Needed for DESTROY to work
});
```

### Hardcoded Values

**❌ Bad: Magic strings and numbers**
```typescript
const fn = new lambda.Function(this, 'Fn', {
  timeout: cdk.Duration.seconds(900),
  memorySize: 3008,
  environment: {
    BUCKET_NAME: 'my-production-bucket-123',
  },
});
```

**✅ Good: Constants and references**
```typescript
const MAX_TIMEOUT = cdk.Duration.minutes(15);
const OPTIMAL_MEMORY = 1024;

const fn = new lambda.Function(this, 'Fn', {
  timeout: cdk.Duration.seconds(30),
  memorySize: OPTIMAL_MEMORY,
  environment: {
    BUCKET_NAME: bucket.bucketName, // Reference
  },
});
```

### Missing Tags

**❌ Bad: No resource tagging**
```typescript
const stack = new cdk.Stack(app, 'MyStack');
```

**✅ Good: Consistent tagging**
```typescript
const stack = new cdk.Stack(app, 'MyStack');
cdk.Tags.of(stack).add('Environment', 'Production');
cdk.Tags.of(stack).add('Owner', 'platform-team');
cdk.Tags.of(stack).add('CostCenter', 'engineering');
```

## Lambda Anti-Patterns

### Excessive Timeout

**❌ Bad: Maximum timeout for simple functions**
```typescript
const fn = new lambda.Function(this, 'Fn', {
  timeout: cdk.Duration.minutes(15), // Way too long!
});
```

**✅ Good: Appropriate timeout**
```typescript
const fn = new lambda.Function(this, 'Fn', {
  timeout: cdk.Duration.seconds(30), // Match expected duration
});
```

### No Reserved Concurrency

**❌ Bad: Unlimited concurrency**
```typescript
const fn = new lambda.Function(this, 'Fn', {
  // No concurrency limit - can run up AWS bill
});
```

**✅ Good: Set concurrency limits**
```typescript
const fn = new lambda.Function(this, 'Fn', {
  reservedConcurrentExecutions: 10, // Prevent runaway costs
});
```

### Bundling Dependencies Incorrectly

**❌ Bad: Including node_modules**
```typescript
const fn = new lambda.Function(this, 'Fn', {
  code: lambda.Code.fromAsset('lambda'), // Includes all node_modules!
});
```

**✅ Good: Use bundling or exclude properly**
```typescript
const fn = new lambda.NodejsFunction(this, 'Fn', {
  entry: 'lambda/index.ts',
  bundling: {
    externalModules: ['aws-sdk'], // Exclude AWS SDK
  },
});
```

## ECS Anti-Patterns

### No Health Checks

**❌ Bad: No container health check**
```typescript
const container = taskDef.addContainer('app', {
  image: ecs.ContainerImage.fromRegistry('nginx'),
  // No healthCheck!
});
```

**✅ Good: Define health check**
```typescript
const container = taskDef.addContainer('app', {
  image: ecs.ContainerImage.fromRegistry('nginx'),
  healthCheck: {
    command: ['CMD-SHELL', 'curl -f http://localhost/health || exit 1'],
    interval: cdk.Duration.seconds(30),
    timeout: cdk.Duration.seconds(5),
    retries: 3,
  },
});
```

### Single Task Deployment

**❌ Bad: Single instance**
```typescript
const service = new ecs.FargateService(this, 'Service', {
  taskDefinition,
  desiredCount: 1, // Single point of failure
});
```

**✅ Good: Multiple tasks for HA**
```typescript
const service = new ecs.FargateService(this, 'Service', {
  taskDefinition,
  desiredCount: 2,
  minHealthyPercent: 50,
  maxHealthyPercent: 200,
});
```

### Missing Circuit Breaker

**❌ Bad: No deployment protection**
```typescript
const service = new ecs.FargateService(this, 'Service', {
  taskDefinition,
  // No circuitBreaker
});
```

**✅ Good: Enable circuit breaker**
```typescript
const service = new ecs.FargateService(this, 'Service', {
  taskDefinition,
  circuitBreaker: { rollback: true },
});
```

## Cost Anti-Patterns

### Oversized Resources

**❌ Bad: Over-provisioning**
```typescript
const fn = new lambda.Function(this, 'Fn', {
  memorySize: 10240, // 10GB for hello world!
  timeout: cdk.Duration.minutes(15),
});
```

**✅ Good: Right-sized**
```typescript
const fn = new lambda.Function(this, 'Fn', {
  memorySize: 256, // Start small
  timeout: cdk.Duration.seconds(30),
});
```

### No Lifecycle Policies

**❌ Bad: Infinite retention**
```typescript
const bucket = new s3.Bucket(this, 'LogBucket', {
  // Logs kept forever!
});
```

**✅ Good: Lifecycle rules**
```typescript
const bucket = new s3.Bucket(this, 'LogBucket', {
  lifecycleRules: [{
    expiration: cdk.Duration.days(30),
  }],
});
```

### Always-On NAT Gateways

**❌ Bad: NAT Gateway in dev**
```typescript
const vpc = new ec2.Vpc(this, 'DevVPC', {
  natGateways: 2, // $90+/month for dev!
});
```

**✅ Good: Environment-specific**
```typescript
const isProd = this.node.tryGetContext('env') === 'prod';
const vpc = new ec2.Vpc(this, 'VPC', {
  natGateways: isProd ? 2 : 0, // Use VPC endpoints in dev
});
```

## Deployment Anti-Patterns

### No Stack Outputs

**❌ Bad: No way to reference resources**
```typescript
const api = new apigateway.RestApi(this, 'Api', { /* ... */ });
// No output!
```

**✅ Good: Export important values**
```typescript
const api = new apigateway.RestApi(this, 'Api', { /* ... */ });
new cdk.CfnOutput(this, 'ApiUrl', {
  value: api.url,
  exportName: 'ApiEndpoint',
});
```

### Mutable Infrastructure

**❌ Bad: Manual updates**
```typescript
// Making changes by editing console, then forgetting to update CDK
```

**✅ Good: All changes via CDK**
```typescript
// Make all infrastructure changes through CDK code
// Use drift detection to catch manual changes
```

### No Stack Naming Convention

**❌ Bad: Generic names**
```typescript
new cdk.Stack(app, 'Stack1');
new cdk.Stack(app, 'TheStack');
```

**✅ Good: Descriptive naming**
```typescript
new cdk.Stack(app, 'MyApp-Network-Production');
new cdk.Stack(app, 'MyApp-Api-Production');
```
