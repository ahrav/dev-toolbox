# L1 to L2 Construct Upgrade Patterns

## Why Upgrade to L2 Constructs?

L2 constructs provide:
- Better defaults (encryption, versioning, etc.)
- Type safety and IDE autocomplete
- Convenience methods (grant*, add* methods)
- Less boilerplate code
- Better error messages

## Common Upgrade Patterns

### S3 Bucket

**❌ L1 (CfnBucket):**
```typescript
const bucket = new s3.CfnBucket(this, 'Bucket', {
  bucketName: 'my-bucket',
  versioningConfiguration: {
    status: 'Enabled',
  },
  bucketEncryption: {
    serverSideEncryptionConfiguration: [{
      serverSideEncryptionByDefault: {
        sseAlgorithm: 'AES256',
      },
    }],
  },
  publicAccessBlockConfiguration: {
    blockPublicAcls: true,
    blockPublicPolicy: true,
    ignorePublicAcls: true,
    restrictPublicBuckets: true,
  },
  lifecycleConfiguration: {
    rules: [{
      status: 'Enabled',
      transitions: [{
        storageClass: 'INTELLIGENT_TIERING',
        transitionInDays: 0,
      }],
    }],
  },
});
```

**✅ L2 (Bucket):**
```typescript
const bucket = new s3.Bucket(this, 'Bucket', {
  bucketName: 'my-bucket',
  versioned: true,
  encryption: s3.BucketEncryption.S3_MANAGED,
  blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
  lifecycleRules: [{
    transitions: [{
      storageClass: s3.StorageClass.INTELLIGENT_TIERING,
      transitionAfter: cdk.Duration.days(0),
    }],
  }],
  removalPolicy: cdk.RemovalPolicy.RETAIN,
});
```

**Benefits:** 50% less code, automatic defaults, safer removal policy

### Lambda Function

**❌ L1 (CfnFunction):**
```typescript
const role = new iam.Role(this, 'Role', {
  assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
});
role.addManagedPolicy(
  iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole')
);

const fn = new lambda.CfnFunction(this, 'Function', {
  functionName: 'my-function',
  runtime: 'nodejs18.x',
  handler: 'index.handler',
  code: {
    s3Bucket: 'my-code-bucket',
    s3Key: 'function.zip',
  },
  role: role.roleArn,
  timeout: 30,
  memorySize: 256,
  environment: {
    variables: {
      TABLE_NAME: 'my-table',
    },
  },
});
```

**✅ L2 (Function):**
```typescript
const fn = new lambda.Function(this, 'Function', {
  functionName: 'my-function',
  runtime: lambda.Runtime.NODEJS_18_X,
  handler: 'index.handler',
  code: lambda.Code.fromAsset('lambda'),
  timeout: cdk.Duration.seconds(30),
  memorySize: 256,
  environment: {
    TABLE_NAME: table.tableName,
  },
});
```

**Benefits:** Automatic role creation, better code handling, Duration type safety

### DynamoDB Table

**❌ L1 (CfnTable):**
```typescript
const table = new dynamodb.CfnTable(this, 'Table', {
  tableName: 'my-table',
  attributeDefinitions: [
    { attributeName: 'pk', attributeType: 'S' },
    { attributeName: 'sk', attributeType: 'S' },
  ],
  keySchema: [
    { attributeName: 'pk', keyType: 'HASH' },
    { attributeName: 'sk', keyType: 'RANGE' },
  ],
  billingMode: 'PAY_PER_REQUEST',
  streamSpecification: {
    streamViewType: 'NEW_AND_OLD_IMAGES',
  },
  pointInTimeRecoverySpecification: {
    pointInTimeRecoveryEnabled: true,
  },
  sseSpecification: {
    sseEnabled: true,
  },
});
```

**✅ L2 (Table):**
```typescript
const table = new dynamodb.Table(this, 'Table', {
  tableName: 'my-table',
  partitionKey: { name: 'pk', type: dynamodb.AttributeType.STRING },
  sortKey: { name: 'sk', type: dynamodb.AttributeType.STRING },
  billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
  stream: dynamodb.StreamViewType.NEW_AND_OLD_IMAGES,
  pointInTimeRecovery: true,
  encryption: dynamodb.TableEncryption.AWS_MANAGED,
  removalPolicy: cdk.RemovalPolicy.RETAIN,
});
```

**Benefits:** Simpler key schema, better defaults, automatic encryption

### IAM Role

**❌ L1 (CfnRole):**
```typescript
const role = new iam.CfnRole(this, 'Role', {
  roleName: 'my-role',
  assumeRolePolicyDocument: {
    Version: '2012-10-17',
    Statement: [{
      Effect: 'Allow',
      Principal: {
        Service: 'lambda.amazonaws.com',
      },
      Action: 'sts:AssumeRole',
    }],
  },
  policies: [{
    policyName: 'inline-policy',
    policyDocument: {
      Version: '2012-10-17',
      Statement: [{
        Effect: 'Allow',
        Action: ['s3:GetObject'],
        Resource: 'arn:aws:s3:::my-bucket/*',
      }],
    },
  }],
  managedPolicyArns: [
    'arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole',
  ],
});
```

**✅ L2 (Role):**
```typescript
const role = new iam.Role(this, 'Role', {
  roleName: 'my-role',
  assumedBy: new iam.ServicePrincipal('lambda.amazonaws.com'),
  managedPolicies: [
    iam.ManagedPolicy.fromAwsManagedPolicyName('service-role/AWSLambdaBasicExecutionRole'),
  ],
});

bucket.grantRead(role);
```

**Benefits:** Simpler trust policy, grant methods instead of inline policies

### Security Group

**❌ L1 (CfnSecurityGroup):**
```typescript
const sg = new ec2.CfnSecurityGroup(this, 'SG', {
  groupDescription: 'My security group',
  vpcId: vpc.vpcId,
  securityGroupIngress: [{
    ipProtocol: 'tcp',
    fromPort: 443,
    toPort: 443,
    cidrIp: '0.0.0.0/0',
  }],
  securityGroupEgress: [{
    ipProtocol: 'tcp',
    fromPort: 443,
    toPort: 443,
    cidrIp: '0.0.0.0/0',
  }],
});
```

**✅ L2 (SecurityGroup):**
```typescript
const sg = new ec2.SecurityGroup(this, 'SG', {
  vpc,
  description: 'My security group',
  allowAllOutbound: false,
});

sg.addIngressRule(
  ec2.Peer.anyIpv4(),
  ec2.Port.tcp(443),
  'Allow HTTPS from anywhere'
);

sg.addEgressRule(
  ec2.Peer.anyIpv4(),
  ec2.Port.tcp(443),
  'Allow HTTPS to anywhere'
);
```

**Benefits:** Better rule management, type-safe ports, descriptive rules

### ALB

**❌ L1 (CfnLoadBalancer + CfnTargetGroup + CfnListener):**
```typescript
const alb = new elbv2.CfnLoadBalancer(this, 'ALB', {
  name: 'my-alb',
  type: 'application',
  scheme: 'internet-facing',
  subnets: vpc.publicSubnets.map(s => s.subnetId),
  securityGroups: [sg.securityGroupId],
});

const tg = new elbv2.CfnTargetGroup(this, 'TG', {
  name: 'my-tg',
  port: 80,
  protocol: 'HTTP',
  vpcId: vpc.vpcId,
  targetType: 'ip',
  healthCheckPath: '/health',
  healthCheckIntervalSeconds: 30,
  healthCheckTimeoutSeconds: 5,
  healthyThresholdCount: 2,
  unhealthyThresholdCount: 3,
});

const listener = new elbv2.CfnListener(this, 'Listener', {
  loadBalancerArn: alb.attrLoadBalancerArn,
  port: 443,
  protocol: 'HTTPS',
  certificates: [{ certificateArn: cert.certificateArn }],
  defaultActions: [{
    type: 'forward',
    targetGroupArn: tg.ref,
  }],
});
```

**✅ L2 (ApplicationLoadBalancer):**
```typescript
const alb = new elbv2.ApplicationLoadBalancer(this, 'ALB', {
  vpc,
  internetFacing: true,
  securityGroup: sg,
});

const listener = alb.addListener('Listener', {
  port: 443,
  protocol: elbv2.ApplicationProtocol.HTTPS,
  certificates: [certificate],
});

listener.addTargets('Targets', {
  port: 80,
  protocol: elbv2.ApplicationProtocol.HTTP,
  targets: [service],
  healthCheck: {
    path: '/health',
    interval: cdk.Duration.seconds(30),
    timeout: cdk.Duration.seconds(5),
    healthyThresholdCount: 2,
    unhealthyThresholdCount: 3,
  },
});
```

**Benefits:** Integrated configuration, automatic associations, better defaults

### ECS Task Definition

**❌ L1 (CfnTaskDefinition):**
```typescript
const taskDef = new ecs.CfnTaskDefinition(this, 'TaskDef', {
  family: 'my-task',
  cpu: '256',
  memory: '512',
  networkMode: 'awsvpc',
  requiresCompatibilities: ['FARGATE'],
  executionRoleArn: execRole.roleArn,
  taskRoleArn: taskRole.roleArn,
  containerDefinitions: [{
    name: 'app',
    image: 'nginx:latest',
    portMappings: [{
      containerPort: 80,
      protocol: 'tcp',
    }],
    logConfiguration: {
      logDriver: 'awslogs',
      options: {
        'awslogs-group': logGroup.logGroupName,
        'awslogs-region': cdk.Stack.of(this).region,
        'awslogs-stream-prefix': 'app',
      },
    },
  }],
});
```

**✅ L2 (FargateTaskDefinition):**
```typescript
const taskDef = new ecs.FargateTaskDefinition(this, 'TaskDef', {
  family: 'my-task',
  cpu: 256,
  memoryLimitMiB: 512,
  executionRole: execRole,
  taskRole: taskRole,
});

const container = taskDef.addContainer('app', {
  image: ecs.ContainerImage.fromRegistry('nginx:latest'),
  portMappings: [{
    containerPort: 80,
  }],
  logging: ecs.LogDrivers.awsLogs({
    streamPrefix: 'app',
    logGroup,
  }),
});
```

**Benefits:** Automatic role creation, better container config, simpler logging

### RDS Instance

**❌ L1 (CfnDBInstance):**
```typescript
const instance = new rds.CfnDBInstance(this, 'Database', {
  dbInstanceIdentifier: 'my-db',
  engine: 'postgres',
  engineVersion: '15.3',
  dbInstanceClass: 'db.t3.micro',
  allocatedStorage: '20',
  storageType: 'gp3',
  storageEncrypted: true,
  masterUsername: 'admin',
  masterUserPassword: 'INSECURE!',
  vpcSecurityGroups: [sg.securityGroupId],
  dbSubnetGroupName: subnetGroup.ref,
  backupRetentionPeriod: 7,
  deletionProtection: true,
  enableCloudwatchLogsExports: ['postgresql'],
});
```

**✅ L2 (DatabaseInstance):**
```typescript
const instance = new rds.DatabaseInstance(this, 'Database', {
  instanceIdentifier: 'my-db',
  engine: rds.DatabaseInstanceEngine.postgres({
    version: rds.PostgresEngineVersion.VER_15_3,
  }),
  instanceType: ec2.InstanceType.of(
    ec2.InstanceClass.T3,
    ec2.InstanceSize.MICRO
  ),
  vpc,
  vpcSubnets: {
    subnetType: ec2.SubnetType.PRIVATE_ISOLATED,
  },
  credentials: rds.Credentials.fromGeneratedSecret('admin'),
  storageEncrypted: true,
  backupRetention: cdk.Duration.days(7),
  deletionProtection: true,
  cloudwatchLogsExports: ['postgresql'],
  removalPolicy: cdk.RemovalPolicy.SNAPSHOT,
});
```

**Benefits:** Generated secrets, automatic subnet group, better credentials

### SNS Topic + Subscription

**❌ L1 (CfnTopic + CfnSubscription):**
```typescript
const topic = new sns.CfnTopic(this, 'Topic', {
  topicName: 'my-topic',
  kmsMasterKeyId: key.keyId,
});

const subscription = new sns.CfnSubscription(this, 'Sub', {
  topicArn: topic.attrTopicArn,
  protocol: 'email',
  endpoint: 'alerts@example.com',
});
```

**✅ L2 (Topic):**
```typescript
const topic = new sns.Topic(this, 'Topic', {
  topicName: 'my-topic',
  masterKey: key,
});

topic.addSubscription(
  new subscriptions.EmailSubscription('alerts@example.com')
);
```

**Benefits:** Integrated subscriptions, simpler API

### SQS Queue + DLQ

**❌ L1 (CfnQueue):**
```typescript
const dlq = new sqs.CfnQueue(this, 'DLQ', {
  queueName: 'my-dlq',
  messageRetentionPeriod: 1209600, // 14 days in seconds
});

const queue = new sqs.CfnQueue(this, 'Queue', {
  queueName: 'my-queue',
  visibilityTimeout: 30,
  redrivePolicy: {
    deadLetterTargetArn: dlq.attrArn,
    maxReceiveCount: 3,
  },
  kmsMasterKeyId: key.keyId,
});
```

**✅ L2 (Queue):**
```typescript
const dlq = new sqs.Queue(this, 'DLQ', {
  queueName: 'my-dlq',
  retentionPeriod: cdk.Duration.days(14),
});

const queue = new sqs.Queue(this, 'Queue', {
  queueName: 'my-queue',
  visibilityTimeout: cdk.Duration.seconds(30),
  deadLetterQueue: {
    queue: dlq,
    maxReceiveCount: 3,
  },
  encryption: sqs.QueueEncryption.KMS,
  encryptionMasterKey: key,
});
```

**Benefits:** Duration type safety, integrated DLQ config

## Detection Patterns

When reviewing code, flag these L1 usage patterns:

### Detect L1 Imports
```typescript
import { CfnBucket } from 'aws-cdk-lib/aws-s3';
import { CfnFunction } from 'aws-cdk-lib/aws-lambda';
import { CfnTable } from 'aws-cdk-lib/aws-dynamodb';
```

### Detect L1 Instantiation
```typescript
new s3.CfnBucket(this, 'Bucket', { ... });
new lambda.CfnFunction(this, 'Function', { ... });
new dynamodb.CfnTable(this, 'Table', { ... });
```

### Check for L2 Availability
Before suggesting upgrade, verify L2 construct exists and covers use case.

**When L1 is acceptable:**
- Property not yet available in L2
- Escape hatch needed for specific CloudFormation property
- Using addPropertyOverride for temporary workaround

## Upgrade Strategy

1. **Identify L1 usage** - Scan for CfnXxx imports and instantiations
2. **Check L2 availability** - Verify L2 construct exists
3. **Review dependencies** - Note resources referencing the L1
4. **Create L2 equivalent** - Write L2 code with same configuration
5. **Migrate references** - Update dependent resources to use L2 properties
6. **Test** - Run `cdk diff` to verify no unintended changes
7. **Deploy** - Apply changes incrementally

## L2 Migration Checklist

- [ ] Replace CfnXxx with L2 equivalent
- [ ] Remove manual role/policy creation if L2 handles it
- [ ] Update resource references (.ref → .bucketName, .attrArn → .functionArn, etc.)
- [ ] Add removalPolicy for stateful resources
- [ ] Use grant methods instead of manual IAM
- [ ] Use Duration types instead of raw seconds
- [ ] Add type-safe enums instead of strings
- [ ] Run cdk diff to verify no unwanted changes
- [ ] Test deployment in non-prod environment
