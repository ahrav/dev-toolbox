# CDK Cost Optimization Patterns

## Lambda Cost Optimization

### Right-Size Memory

```typescript
// ❌ Over-provisioned
const fn = new lambda.Function(this, 'Fn', {
  memorySize: 3008, // Max memory for simple task
  timeout: cdk.Duration.minutes(15), // Max timeout
});

// ✅ Right-sized
const fn = new lambda.Function(this, 'Fn', {
  memorySize: 256, // Start small, increase based on metrics
  timeout: cdk.Duration.seconds(30),
});
```

**Cost Impact:** Lambda charges per GB-second. 3008MB vs 256MB = 11.7x cost difference

### Reserved Concurrency

```typescript
// Prevent runaway costs
const fn = new lambda.Function(this, 'Fn', {
  reservedConcurrentExecutions: 10, // Limit concurrent executions
});
```

### Use ARM64 Architecture

```typescript
const fn = new lambda.Function(this, 'Fn', {
  architecture: lambda.Architecture.ARM_64, // 20% cheaper than x86
  runtime: lambda.Runtime.NODEJS_18_X,
});
```

## ECS/Fargate Cost Optimization

### Use Fargate Spot

```typescript
const service = new ecs.FargateService(this, 'Service', {
  cluster,
  taskDefinition,
  capacityProviderStrategies: [
    {
      capacityProvider: 'FARGATE_SPOT',
      weight: 2, // 70% spot
      base: 0,
    },
    {
      capacityProvider: 'FARGATE',
      weight: 1, // 30% on-demand for stability
      base: 2, // Minimum 2 on-demand tasks
    },
  ],
});
```

**Cost Impact:** Fargate Spot is up to 70% cheaper than on-demand

### Right-Size Task Resources

```typescript
// ❌ Over-provisioned
const taskDef = new ecs.FargateTaskDefinition(this, 'Task', {
  cpu: 4096,
  memoryLimitMiB: 8192,
});

// ✅ Right-sized
const taskDef = new ecs.FargateTaskDefinition(this, 'Task', {
  cpu: 256,
  memoryLimitMiB: 512,
  // Monitor CloudWatch metrics and adjust
});
```

### Use Scheduled Scaling for Dev/Test

```typescript
const scaling = service.autoScaleTaskCount({
  minCapacity: 0, // Scale to 0 during off-hours
  maxCapacity: 10,
});

// Scale down at night (dev/test only)
scaling.scaleOnSchedule('ScaleDown', {
  schedule: appscaling.Schedule.cron({ hour: '20', minute: '0' }),
  minCapacity: 0,
  maxCapacity: 0,
});

// Scale up in morning
scaling.scaleOnSchedule('ScaleUp', {
  schedule: appscaling.Schedule.cron({ hour: '8', minute: '0' }),
  minCapacity: 2,
  maxCapacity: 10,
});
```

## NAT Gateway Cost Optimization

### Eliminate NAT Gateways in Dev

```typescript
const isProd = this.node.tryGetContext('env') === 'prod';

const vpc = new ec2.Vpc(this, 'VPC', {
  natGateways: isProd ? 2 : 0, // $90+/month savings per NAT
  maxAzs: isProd ? 3 : 2,
});

// Use VPC endpoints instead
if (!isProd) {
  vpc.addGatewayEndpoint('S3', {
    service: ec2.GatewayVpcEndpointAwsService.S3,
  });
  
  vpc.addInterfaceEndpoint('ECR', {
    service: ec2.InterfaceVpcEndpointAwsService.ECR,
  });
}
```

**Cost Impact:** Each NAT Gateway costs ~$45/month + data processing fees

### Single NAT Gateway for Non-Prod

```typescript
const vpc = new ec2.Vpc(this, 'VPC', {
  natGateways: 1, // Single NAT for non-prod
  natGatewaySubnets: {
    availabilityZones: [vpc.availabilityZones[0]],
  },
});
```

## S3 Cost Optimization

### Lifecycle Rules

```typescript
const bucket = new s3.Bucket(this, 'Bucket', {
  lifecycleRules: [
    {
      // Move to IA after 30 days
      transitions: [{
        storageClass: s3.StorageClass.INFREQUENT_ACCESS,
        transitionAfter: cdk.Duration.days(30),
      }],
    },
    {
      // Move logs to Glacier after 90 days
      prefix: 'logs/',
      transitions: [{
        storageClass: s3.StorageClass.GLACIER,
        transitionAfter: cdk.Duration.days(90),
      }],
      expiration: cdk.Duration.days(365),
    },
    {
      // Delete old versions after 90 days
      noncurrentVersionTransitions: [{
        storageClass: s3.StorageClass.GLACIER,
        transitionAfter: cdk.Duration.days(30),
      }],
      noncurrentVersionExpiration: cdk.Duration.days(90),
    },
  ],
});
```

**Cost Impact:** IA is 46% cheaper than Standard, Glacier is 80% cheaper

### Intelligent Tiering

```typescript
const bucket = new s3.Bucket(this, 'Bucket', {
  intelligentTieringConfigurations: [{
    name: 'archive',
    archiveAccessTierTime: cdk.Duration.days(90),
    deepArchiveAccessTierTime: cdk.Duration.days(180),
  }],
});
```

### Delete Incomplete Multipart Uploads

```typescript
const bucket = new s3.Bucket(this, 'Bucket', {
  lifecycleRules: [{
    abortIncompleteMultipartUploadAfter: cdk.Duration.days(7),
  }],
});
```

## RDS Cost Optimization

### Use Aurora Serverless v2

```typescript
// ❌ Provisioned instance always running
const cluster = new rds.DatabaseCluster(this, 'DB', {
  engine: rds.DatabaseClusterEngine.auroraPostgres({
    version: rds.AuroraPostgresEngineVersion.VER_15_3,
  }),
  instances: 2,
  instanceProps: {
    instanceType: ec2.InstanceType.of(
      ec2.InstanceClass.R6G,
      ec2.InstanceSize.XLARGE
    ),
    vpc,
  },
});

// ✅ Serverless v2 - scales to zero
const cluster = new rds.DatabaseCluster(this, 'DB', {
  engine: rds.DatabaseClusterEngine.auroraPostgres({
    version: rds.AuroraPostgresEngineVersion.VER_15_3,
  }),
  serverlessV2MinCapacity: 0.5, // Scale down to 0.5 ACU
  serverlessV2MaxCapacity: 16,
  writer: rds.ClusterInstance.serverlessV2('writer'),
  vpc,
});
```

### Scheduled Start/Stop for Dev

```typescript
// Start database at 8 AM
new events.Rule(this, 'StartDB', {
  schedule: events.Schedule.cron({ hour: '8', minute: '0' }),
  targets: [new targets.AwsApi({
    service: 'RDS',
    action: 'startDBInstance',
    parameters: {
      DBInstanceIdentifier: instance.instanceIdentifier,
    },
  })],
});

// Stop database at 8 PM
new events.Rule(this, 'StopDB', {
  schedule: events.Schedule.cron({ hour: '20', minute: '0' }),
  targets: [new targets.AwsApi({
    service: 'RDS',
    action: 'stopDBInstance',
    parameters: {
      DBInstanceIdentifier: instance.instanceIdentifier,
    },
  })],
});
```

## CloudWatch Logs Cost Optimization

### Set Retention Periods

```typescript
// ❌ Logs kept forever
const logGroup = new logs.LogGroup(this, 'Logs', {
  // No retention set - stored indefinitely!
});

// ✅ Explicit retention
const logGroup = new logs.LogGroup(this, 'Logs', {
  retention: logs.RetentionDays.ONE_WEEK, // Delete after 7 days
});
```

**Cost Impact:** CloudWatch Logs charges $0.50/GB for storage

### Use Subscription Filters to S3

```typescript
// Stream logs to S3 for long-term storage (cheaper)
const destination = new logs_destinations.S3Destination(archiveBucket);

logGroup.addSubscriptionFilter('ToS3', {
  destination,
  filterPattern: logs.FilterPattern.allEvents(),
});
```

## EC2/ECS Instance Cost Optimization

### Use Graviton2/Graviton3

```typescript
// ✅ 40% better price-performance
const instance = new ec2.Instance(this, 'Instance', {
  instanceType: ec2.InstanceType.of(
    ec2.InstanceClass.T4G, // Graviton2
    ec2.InstanceSize.MICRO
  ),
  machineImage: ec2.MachineImage.latestAmazonLinux2023({
    cpuType: ec2.AmazonLinuxCpuType.ARM_64,
  }),
  vpc,
});
```

### Use Spot Instances for Fault-Tolerant Workloads

```typescript
const asg = new autoscaling.AutoScalingGroup(this, 'ASG', {
  vpc,
  instanceType: ec2.InstanceType.of(
    ec2.InstanceClass.T3,
    ec2.InstanceSize.MEDIUM
  ),
  machineImage: ec2.MachineImage.latestAmazonLinux2023(),
  spotPrice: '0.05', // Up to 90% savings
});
```

## API Gateway Cost Optimization

### Use HTTP API Instead of REST API

```typescript
// ✅ HTTP API - 70% cheaper
const httpApi = new apigatewayv2.HttpApi(this, 'HttpApi', {
  defaultIntegration: new integrations.HttpLambdaIntegration(
    'Integration',
    fn
  ),
});

// ❌ REST API - more expensive
const restApi = new apigateway.RestApi(this, 'RestApi', {
  defaultIntegration: new apigateway.LambdaIntegration(fn),
});
```

### Enable Caching (When Appropriate)

```typescript
const api = new apigateway.RestApi(this, 'Api', {
  deployOptions: {
    cachingEnabled: true,
    cacheClusterSize: '0.5', // 0.5 GB cache
    cacheTtl: cdk.Duration.minutes(5),
  },
});
```

## DynamoDB Cost Optimization

### Use On-Demand for Unpredictable Workloads

```typescript
const table = new dynamodb.Table(this, 'Table', {
  partitionKey: { name: 'pk', type: dynamodb.AttributeType.STRING },
  billingMode: dynamodb.BillingMode.PAY_PER_REQUEST, // No over-provisioning
});
```

### Use Provisioned with Auto-Scaling for Predictable Workloads

```typescript
const table = new dynamodb.Table(this, 'Table', {
  partitionKey: { name: 'pk', type: dynamodb.AttributeType.STRING },
  billingMode: dynamodb.BillingMode.PROVISIONED,
  readCapacity: 5,
  writeCapacity: 5,
});

// Auto-scale based on utilization
table.autoScaleReadCapacity({
  minCapacity: 5,
  maxCapacity: 100,
}).scaleOnUtilization({
  targetUtilizationPercent: 70,
});
```

### Use TTL for Automatic Data Expiration

```typescript
const table = new dynamodb.Table(this, 'Table', {
  partitionKey: { name: 'pk', type: dynamodb.AttributeType.STRING },
  timeToLiveAttribute: 'expiresAt', // Automatic deletion
});
```

## Cross-Service Cost Patterns

### Environment-Specific Resource Sizing

```typescript
interface EnvironmentConfig {
  lambdaMemory: number;
  fargateTaskCount: number;
  natGateways: number;
  rdsInstanceSize: ec2.InstanceSize;
}

const configs: Record<string, EnvironmentConfig> = {
  prod: {
    lambdaMemory: 1024,
    fargateTaskCount: 3,
    natGateways: 2,
    rdsInstanceSize: ec2.InstanceSize.LARGE,
  },
  staging: {
    lambdaMemory: 512,
    fargateTaskCount: 2,
    natGateways: 1,
    rdsInstanceSize: ec2.InstanceSize.MEDIUM,
  },
  dev: {
    lambdaMemory: 256,
    fargateTaskCount: 1,
    natGateways: 0,
    rdsInstanceSize: ec2.InstanceSize.SMALL,
  },
};

const env = this.node.tryGetContext('environment') || 'dev';
const config = configs[env];
```

### Tag Resources for Cost Allocation

```typescript
cdk.Tags.of(stack).add('Environment', environment);
cdk.Tags.of(stack).add('CostCenter', 'engineering');
cdk.Tags.of(stack).add('Project', projectName);
```

## Cost Monitoring

### Set Up Budget Alarms

```typescript
const budget = new budgets.CfnBudget(this, 'MonthlyBudget', {
  budget: {
    budgetName: 'monthly-budget',
    budgetType: 'COST',
    timeUnit: 'MONTHLY',
    budgetLimit: {
      amount: 1000,
      unit: 'USD',
    },
  },
  notificationsWithSubscribers: [{
    notification: {
      notificationType: 'ACTUAL',
      comparisonOperator: 'GREATER_THAN',
      threshold: 80, // Alert at 80%
    },
    subscribers: [{
      subscriptionType: 'EMAIL',
      address: 'billing@example.com',
    }],
  }],
});
```

## Cost Review Checklist

Review CDK stacks for these cost optimization opportunities:

- [ ] Lambda memory sized appropriately (not max)
- [ ] Lambda reserved concurrency set to prevent runaway costs
- [ ] ECS/Fargate using Spot capacity where appropriate
- [ ] NAT Gateways minimized or eliminated in non-prod
- [ ] S3 lifecycle rules configured
- [ ] CloudWatch Logs retention periods set
- [ ] RDS using appropriate instance types (or serverless)
- [ ] DynamoDB using appropriate billing mode
- [ ] API Gateway using HTTP API instead of REST API where possible
- [ ] Resources sized differently per environment
- [ ] Auto-scaling configured for variable workloads
- [ ] Unused resources cleaned up (old snapshots, EBS volumes, etc.)
- [ ] Cost allocation tags applied consistently
- [ ] Budget alarms configured
